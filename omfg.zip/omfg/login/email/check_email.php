<html>
<head>
<meta charset="utf-8">
<?php 
include "../lib/dbconn.php";

$id =$_GET['id'];
$name = $_GET['name'];
$sql = "select * from member_table where userid='$id' and username='$name'"; /*문자열은 ' ' 마크 해줘야 함!  */
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_array($result);

$db_id = $row['userid'];
$db_name = $row['username'];
$db_email = $row['email'];



?>

</head>
<script>
function email_confirm(email){
	if(!document.email_search.email.value){
		alert("이메일을 입력하세요");
		document.email_search.email.select();	
		return;
	}
	if(document.email_search.email.value!=email){
		alert("이메일이 일치하지 않습니다. 다시 입력해주세요");
		return;
	}	
	document.email_search.submit();
	alert("인증번호 전송 완료!");
}

</script>
<body>
	<div id="title">
		<img src="../img/email_confirm.jpg">
	</div><br>

	<div id="content">
	<form name="email_search" method="post" action="./email.php">
		<input type="text" id="email" name="email" style="float:left;">&nbsp;
		<input type="hidden" name="userid" value="<?=$db_id?>">
		<img id = "confirm_button" src="../img/confirm.jpg" onclick="email_confirm('<?=$db_email?>');">
	</form>
	</div>
</body>
</html>