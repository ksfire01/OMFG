<html>
<head>
<meta charset="utf-8">
<?php 
include "../lib/dbconn.php";
$code = $_GET['code'];
$id = $_GET['userid'];

echo "$code";
?>

</head>
<script>
function number_ok(code, id){
		if(document.confirm_number.confirm.value!=code){
			alert("인증번호가 일치하지 않습니다.");
			return;
		}
		location.href='./update_pw.php?code='+code+'&userid='+id;
				
	}

</script>
<body>
	
	<div id="content">
	<form name="confirm_number" method="post">
		<div id="title" style="margin: 70 0 30 165">
		<img src="../img/confirm_title.jpg">
		</div>
		<div id="confirm" style="margin: 0 0 0 170">
		<input type="text" id="confirm" name="confirm" style="float:left;">&nbsp;
		<img id = "confirm_ok" src="../img/confirm_ok.jpg" onclick="number_ok(<?=$code?>,'<?=$id?>');">
		</div>
	</form>
	</div>
</body>
</html>
