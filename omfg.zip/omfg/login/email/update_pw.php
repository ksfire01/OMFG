<?php
include "../lib/dbconn.php";
$code = $_GET['code'];
$id = $_GET['userid'];

?>

<html>
<head>
<meta charset="utf-8">
</head>
<script>
function check_password1(){  // 비밀번호 형식 확인
	var pattern =/^[0-9a-zA-Z]{8,16}$/;
	var password1 = document.getElementById("password1");
	
	if(password1.value.match(pattern)){
		pass1.innerHTML="";
		return true;
	}else{
		pass1.innerHTML="형식에 맞게 입력하세요"		
		return false;
	}
	
}
function check_password2(){  // 비밀번호 확인 일치 여부
	
	var password1 = document.getElementById("password1");
	var password2 = document.getElementById("password2");
	
	if(password1.value == password2.value){
		password_text.innerHTML ="비밀번호가 일치합니다."
		return;
	}else{
		password_text.innerHTML="비밀번호가 일치하지 않습니다."
		return;
	}
}

function new_pw(id){
	if(!document.pw_update.pass.value){
		alert("비밀번호를 입력하세요");
		document.pw_update.pass.focus();
		return;
	}
	if(!document.pw_update.pass_confirm.value){
		alert("비밀번호 확인란을 입력하세요");
		document.pw_update.pass_confirm.focus();
		return;
	}
	if(document.pw_update.pass.value!=document.pw_update.pass_confirm.value){
		alert("비밀번호가 일치하지 않습니다.");
		return;
	}	
	
	location.href='../login/get_pw.php?userid='+id+'&pass='+document.pw_update.pass.value;
}

</script>
<body>	
	<div id="content">
	<form name="pw_update" method="post">
		<div id="title" style="margin: 50 0 50 40">
		<img src="../img/update_pw.jpg">
		</div>
		<div id="confirm" style="margin: 0 0 0 40">
		<div id="new_pw1" style="float:left; margin-right: 20px;">새 비밀번호 입력 :</div>
		<input type="password" id="password1" name="pass"
		onblur="check_password1();" style=" float: left; margin-bottom:5px; margin-right: 8px;maxlength=16;">
		<p id="pass1"></p>
		<div id="pw2" style="margin-left:5px; margin-top:5px; font-size: 9pt;">(영문 대소문자/숫자 사용가능, 8-16자)</div><br>
		
		<div id="new_pw2" style="float:left; margin-right: 15px;">비밀번호 입력확인: </div>
		<input type="password" id="password2" name="pass_confirm" onchange="check_password2();">
		<p id="password_text"></p>
		<input type="hidden" name="email" value="<?=$email?>">
		</div>
		<div id="button" style="margin: 50 0 0 260">
			<img src="../img/write_ok.jpg" id="newpw_ok" name="newpw_ok" onclick="new_pw('<?=$id?>');">
		</div>
	</form>
	</div>
</body>
</html>
