<?php
    session_start();
    include "../../top/top.php";
?>
<html>
<head><meta charset="utf-8">
<link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../css/member_form_modify.css" rel="stylesheet" type="text/css" media="all">
</head>
<?php 
    include "../lib/dbconn.php";  

    $sql ="select * from member_table where userid='$userid'";
    
    $result =mysqli_query($con, $sql);
    $row =mysqli_fetch_array($result);
    
    mysqli_close($con);
?>
<body>
	<div id="header">
		
	</div><!-- end of header -->
			
	<div id="title">
		<img src="../img/mypage_title.jpg">
	</div><!-- end of title -->
		<form id="join1">
			<div id="content">
				<div id="point">
				
					<div id="list1">
						<input type="image" id="point1" src="../img/point1.jpg">
						<input type="text" id="pointvalue" value="<?=$row['point']?>원" readonly>
						
						<br>
						<input type="image" id="point3" src="../img/point3.jpg">
						<input type="text" id="totalspend" value="<?=$row['totalspend']?>원" readonly>
						
					</div>
					<div id="list2">
						<input type="image" id="point2" src="../img/point2.jpg">
						<input type="text" id="pointvalue2" value="<?=$row['point']?>원" readonly>
						
						<br>		
						<input type="image" id="point4" src="../img/point4.jpg">
						<input type="text" id="totalprice" value="<?=$row['totalprice']?>회" readonly>
					</div>
				</div><!-- end of point -->
			<div id="ordertable">
				<div id=order>
				<a href="#"><p><b>ORDER</b> 주문내역 조회<br>고객님께서 주문하신 상품의 주문내역을 확인하실 수 있습니다.<br>
				비회원의 경우, 주문서의 주문번호와 비밀번호로 주문조회가 가능합니다.</p>
				</a>
				</div>
				<div id=info>
				<a href="./member_info.php"><p><b>INFO</b> 회원정보<br>회원이신 고객님의 개인정보를 관리하는 공간입니다.<br>
				개인정보를 최신 정보로 유지하시면 보다 간편히 쇼핑을 즐기실 수 있습니다.</p>
				</a>
				</div>
				<div id=wishlist>
				<a href="#"><p><b>WISH LIST</b> 관심 상품<br>관심상품으로 등록하신 상품의 목록을 보여드립니다.<br>
				</a>
				</div>
				<div id=pointvalue>
				<a href="#"><p><b>POINT</b> 적립금<br>적립금은 상품 구매 시 사용하실 수 있습니다.<br>
				적립된 금액은 현금으로 환불되지 않습니다.</p>
				</a>
				</div>
				<div id=myboard>
				<a href="#"><p><b>MY BOARD</b> 게시물 관리<br>고객님께서 작성하신 게시물을 관리하는 공간입니다.<br>
				고객님께서 작성하신 글을 한눈에 관리하실 수 있습니다.</p>
				</a>
				</div>
				<div id=address>
				<a href="#"><p><b>ADDRESS</b> 배송 주소록 관리<br>
				자주 사용하는 배송지를 등록하고 관리하실 수 있습니다.</p>
				</a>
				</div>
			
			</div>
	
	</div> <!-- end of content -->
		</form>
</body>
</html>