<?php
    include "../../top/top.php";
?>

<html>
 <head>
 <meta charset="utf-8">
 <link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
 <link href="../css/member.css" rel="stylesheet" type="text/css" media="all">
  <script>
 	function email_confirm(){
 		if(!document.search_pw.name.value){
 			alert("이름을 입력하세요");
 			document.search_pw.name.focus();
 			document.search_pw.name.select();
 			return;
 		}else if(!document.search_pw.id.value){
 			alert("아이디를 입력하세요");
 			document.search_pw.id.focus();
 			document.search_pw.id.select();
 			return;
 		}  		
 		window.open("../email/check_email.php?name="+document.search_pw.name.value+"&id="+document.search_pw.id.value,"PWcheck","left=200, top=200,width=600, height=400,scrollbars=no,resizable=yes");		
 	} 	
 	
 
 </script>
 </head>
 <?php 
    include '../lib/dbconn.php';
    $sql = "select * from member_table userid ='$userid'";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
    
    mysqli_close($con);
    
    ?> 
    
 <body>
 	
 <div id="wrap">
 	<div id="content">
 	<form name="search_pw" method="post">
 		<div id="title" style="margin-top:100px; margin-left:250px; margin-bottom:20px;">
 			<img src="../img/search_pw2.jpg">
 		</div> <!-- end of title -->
 		
 		<div id="search_login_form" style="margin-left:255px; width:450px; height:190px; border: solid 1px gray;">
 			<table style="margin-left: 40px;margin-top: 35px; margin-bottom: 5px;width:70%; padding:5px;">
 				<tr>
 					<td><img src="../img/name.jpg" style="width:50px;"></td>
 					<td><input type="text" name="name" placeholder="이름" value="<?=$row['username']?>"></td>
 					 
 				</tr>
 				<tr>
 				<td><img src="../img/id.jpg" style="width:50px;"></td>
 				<td><input type="text" name="id" placeholder="아이디"value="<?=$row['userid']?>" ></td>
 				</tr> 			
 				<tr>
 				<td><img src="../img/email.jpg" style="width:50px;"></td>
 				<td><input type="text" name="email" placeholder="이메일" readonly>&nbsp;
 					  <img id = "confirm_button" src="../img/confirm.jpg" onclick="email_confirm();"></td>
 				</tr> 			
 			</table><!-- end of table -->
 			 
 		</div> <!-- end of search_login_form -->
 		</form><!-- end of form -->
 	 	</div><!-- end of content -->
 	</div><!-- end of wrap --> 	
 	 </body>
 </html>
