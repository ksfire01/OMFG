<?php 
    session_start();
    include "../lib/dbconn.php";
    
    $sql = "delete from member_table where userid='$userid'";
    mysqli_query($con, $sql);
    mysqli_close($con);
        
    echo("
        <script>
            location.href='../../newfile.php';
        </script>
        ");   
?>
