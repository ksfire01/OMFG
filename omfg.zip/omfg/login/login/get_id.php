<?php
session_start();
?>
<meta charset="utf-8">

<?php 
$name = $_POST['name'];
$email = $_POST['email'];

if(!$name){
    echo ("
    <script>
        window.alert('이름을 입력하세요');
        history.go(-1);
    </script>
");
    exit();
}
if(!$email){
    echo ("
    <script>
        window.alert('이메일을 입력하세요');
        history.go(-1);
    </script>
");
    exit();
}
    include '../lib/dbconn.php';
    
   $sql ="select * from member_table where username='$username' AND email='$email'";
   $result = mysqli_query($con, $sql);
   $num_record =mysqli_num_rows($result);
   
   if(!$num_record)
   {
       echo ("
        <script>
            window.alert('해당된 아이디가 없습니다.');
            history.go(-1);
        </script>
    ");
   }else{
       echo ("
        <script>
        window.alert('당신의 아이디는 $userid 입니다. 로그인 페이지로 넘어갑니다.');
        </script>
        ");
    mysqli_close($con);
   echo ("
    <script>
        location.href='./login_form.php';
    </script>
    ");
   }
?>