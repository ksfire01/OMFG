<?php
include '../lib/dbconn.php';
?>

<?php
    session_start();
 ?>
 
 <html>
 <head>
 <meta charset="utf-8">
 <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
 <style type="text/css">
        .container#body{
            position: relative;
            width: 1000rem;

        }
        #wrap{
            position: relative;
            top: 100px;
        }
 </style>
 </head>
 
 <body>

 <?php 
    include '../../top/top.php';
 ?>
<div class="container" id="body">
 <div id="wrap">
  
 <div id="content" style="height:400px; margin-left: 15%;">
  
 <div id="login1" style="height:275px;">
 	<form name="member_form" method="post" action="./login.php">
 <div id="title">
 	<img src="../img/title_login.jpg" style="margin-left:300px; margin-top: 50px;margin-bottom:30px;">
 </div><!-- end of title -->
 
 <div id="login_form" style="margin-left: 170px; height: 100px;" >
 	<div id="login2" style="height:180px;">
 		<input type="text" name="id" placeholder=" ID" style="width: 360px; margin-bottom: 10px"><br>
 		<input type="password" name="pass" placeholder=" PASS" style="width: 360px; margin-bottom: 10px"><br>
 		<input type="image" id="login" name="login" src="../img/login_button.jpg" style="margin-left:3px;">
 	  	  		
 	</div>  <!-- end of login1 -->

 </div><!-- end of login_form -->
 </form>
 <div id="search" style="margin-left: 175px; margin-top: 30px">
 		<a href="./search_id.php"><input type="image" id="search_id" name="search_id" src="../img/search_id.jpg"></a>
 		<a href="./search_pw.php"><input type="image" id="search_pw" name="search_pw" src="../img/search_pw.jpg"></a>
  	</div> <!-- end of search -->
 
 </div>	<!-- end of col2 -->
 <div id="member_join" style="margin-left: 178px;">
  	<a href="../member/member_form.php">
  	<input type="image" id="member_join" name="member_join" src="../img/member_join.jpg">
  	 </a>
 </div>
 </div>  <!-- end of content -->
  </div> <!-- end of wrap -->
  </div>
 </body> 
 </html>