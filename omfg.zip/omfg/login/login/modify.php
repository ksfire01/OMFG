<?php
session_start();
?>
<meta charset="utf-8">
<?php 
$userid = $_POST['id'];
$pass = $_POST['pass'];
$hp1 = $_POST['hp1'];
$hp2 = $_POST['hp2'];
$hp3 = $_POST['hp3'];
$email1 = $_POST['email1'];
$email2 = $_POST['email2'];
$post = $_POST['post'];
$addr1 = $_POST['addr1'];
$addr2 = $_POST['addr2'];

$tel=$hp1 ."-". $hp2 ."-". $hp3;
$email=$email1."@".$email2;
    
    include "../lib/dbconn.php";  // dbconn.php 파일을 불러옴
    
    $sql ="update member_table set pass='$pass', username='$name', post='$post',";
    $sql .="addr1='$addr1', addr2='$addr2', tel='$tel', email='$email' where userid='$userid'";
        
    mysqli_query($con, $sql);
    
    mysqli_close($con);
    
    echo("
        <script>
        
        location.href='../../top/top.php';
        </script>
    ");

?>