<?php
    include "../lib/dbconn.php";
    include "../../top/top.php";
?>

<html>
 <head>
 <meta charset="utf-8">
 <link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
 <link href="../css/member.css" rel="stylesheet" type="text/css" media="all">
 </head>
 <body>
 <div id="wrap">
 	<div id="content">
 		<form name="search_id" method="post" action="get_id.php">
 		<div id="title" style="margin-top:100px; margin-left:250px; margin-bottom:10px;">
 			<img src="../img/search_id2.jpg">
 		</div> <!-- end of title -->
 		
 		<div id="search_login_form" style="margin-left:255px; width:400px; height:150px; border: solid 1px gray;">
 			<table style="margin-left: 40px;margin-top: 35px; width:70%; padding:5px;">
 				<tr>
 					<td><img src="../img/name.jpg" style="width:50px;"></td>
 					<td><input type="text" name="name" placeholder="이름"></td>
 					<td rowspan="2">
 					<input type="image" src="../img/ok.jpg" style="width:60px; height:60px;"></td>
 				</tr>
 				<tr>
 				<td><img src="../img/email.jpg" style="width:50px;"></td>
 				<td><input type="text" name="email" placeholder="이메일"></td>
 				</tr> 			
 			</table><!-- end of table --> 		
 		</div> <!-- end of search_login_form --> 			
 		</form><!-- end of form -->
 	 	</div><!-- end of content -->
 	</div><!-- end of wrap --> 	
 	 </body>
 </html>
