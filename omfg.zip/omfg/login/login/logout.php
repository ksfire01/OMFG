<?php
session_start();
include "../../top/top.php";
unset($_SESSION['userid']);
session_unset();
session_destroy();
echo("
    <script>
        location.href='../../newfile.php';
    </script>
");
?>