<?php
include "../lib/dbconn.php";
$id = $_GET['userid'];
$pass = $_GET['pass'];


$sql = "update member_table set pass='$pass' where userid='$id'";
$result = mysqli_query($con, $sql);


mysqli_close($con);


echo("
    <script>
        alert('비밀번호가 변경되었습니다. 로그인 창으로 이동합니다.');
        window.close();
        opener.location.replace('./login_form.php');
    </script>
    ");

?>













?>