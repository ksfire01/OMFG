<?php
include '../lib/dbconn.php';
?>

<meta charset="utf-8">
<?php

$userid= $_GET['id'];

   include "../lib/dbconn.php";
  
    $sql ="select * from member_table where userid='$userid'";
    
    $result =mysqli_query($con, $sql);
    $num_record = mysqli_num_rows($result);
    
    if($num_record){
        echo "아이디가 중복됩니다.<br>";
        echo "다른 아이디를 사용하세요.<br>";
    }else{
        echo "사용 가능한 아이디입니다.";
    }
    mysqli_close($con);

?>