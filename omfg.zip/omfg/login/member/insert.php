<meta charset="utf-8">

<?php
$userid = $_POST['id'];
$pass = $_POST['pass'];
$username = $_POST['name'];
$post = $_POST['post'];
$addr1 = $_POST['addr1'];
$addr2 = $_POST['addr2'];

$hp1 = $_POST['hp1'];
$hp2 = $_POST['hp2'];
$hp3 = $_POST['hp3'];
$email1 = $_POST['email1'];
$email2 = $_POST['email2'];
$year= $_POST['year'];
$month= $_POST['month'];
$day= $_POST['day'];

$tel = $hp1 . "-" . $hp2 . "-" . $hp3;
$email = $email1 . "@" . $email2;
$birth = $year."년" .$month."월".$day."일";



include "../lib/dbconn.php";

   $sql = "insert into member_table(userid, pass, username, post, addr1, addr2, tel, email, birth)";
   $sql .="values('".$userid."','".$pass."','".$username."','".$post."','".$addr1."','".$addr2."','".$tel."','".$email."','".$birth."')";
   
    mysqli_query($con, $sql); // sql에 저장된 명령 실행
    mysqli_close($con);

echo ("
    <script>
        location.href='../../newfile.php';
    </script>
");
?>
