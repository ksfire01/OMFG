<?php
include "../lib/dbconn.php";

$flag = "NO";  // 어떤 기능을 no, yes에 따라 실행하는지 여부를 결정한다.

$sql = "SHOW TABLES FROM shopdb";
$result = mysqli_query($con, $sql);
if (!$result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: '.mysqli_error();
    exit;
}

while ($row = mysqli_fetch_row($result)) {  
    if($row[0]=="member_table")
    {
        $flag = "OK";
        break;
    }
}


/* 테이블이 존재하지 않으면 테이블생성  */
if($flag != "OK")
{
    $sql = "create table member_table (
                userid varchar(20) not null,
                pass varchar(20) not null,
                username char(10) not null,
                post int(11) not null,
                addr1 varchar(50) not null,
                addr2 varchar(50) not null,
                tel varchar(20) not null,
                email varchar(50) not null,
                birth varchar(20) not null,
                point int unsigned DEFAULT 2000,
                rank varchar(4),
                totalspend int unsigned DEFAULT 0,
                totalprice int unsigned DEFAULT 0,
                primary key(userid))";
    
    /*테이블 생성하고 쿼리문 실행  */
    $result = mysqli_query($con, $sql) or die	(mysqli_error($con)); // 여기까지 die문
echo "<script>
        alert('[테이블생성성공] member_table 테이블 생성');
		</script>";
}
mysqli_close($con); //db연결 종료
?>
