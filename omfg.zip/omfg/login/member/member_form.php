<?php
    session_start();
    
?>
<?php include "../../top/top.php"; ?>
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css"
	media="all">
<link href="../css/member.css" rel="stylesheet" type="text/css"
	media="all">
<script src="http://dmaps.daum.net/map_js_init/postcode.v2.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
function check_id(){
	var pattern = "^[a-z0-9]{4,16}$";	
	if(document.member_form.id.value.match(pattern)){
		window.open("check_id.php?id="+document.member_form.id.value,"IDcheck","left=200, top=200, width=200, height=60,scrollbars=no,resizable=yes");
		}else{
			alert("아이디 형식에 맞게 입력바랍니다");
		}
	}

function check_tel(){
	var pattern="^[0-9]{4}$";
	var tel = document.getElementById("hp3");
	
	if(tel.value.match(pattern)){
		hp_text.innerHTML="";
		return true;
		
	}else{
		hp_text.innerHTML="휴대폰 형식에 맞춰 입력하세요";
		return false;
	}
}


function check_password1(){
	var pattern ="^[0-9a-zA-Z]{8,16}$";
	var password1 = document.getElementById("password1");
	
	if(password1.value.match(pattern)){
		return;
	}else{
		alert("형식에 맞게 입력하세요");
	return;
	}
	
}
function check_password2(){
	
	var password1 = document.getElementById("password1");
	var password2 = document.getElementById("password2");
	
	if(password1.value == password2.value){
		password_text.innerHTML =""
		return true;
	}else{
		password_text.innerHTML="비밀번호가 일치하지 않습니다."
		return false;
	}
}

function check_input(){
	if(!document.member_form.id.value){
		alert("아이디를 입력하세요");
		document.member_form.id.focus();
		return;
	}	
	
	if(!document.member_form.pass.value){
		alert("비밀번호를 입력하세요");
		document.member_form.pass.focus();
		return;
	}
		
	if(!document.member_form.pass_confirm.value){
		alert("비밀번호 확인을 입력하세요");
		document.member_form.pass_confirm.focus();
		return;
	}
	
	if(!document.member_form.name.value){
		alert("이름을 입력하세요");
		document.member_form.name.focus();
		return;
	}
	
	if(!document.member_form.addr2.value){
		alert("상세주소를 입력하세요");
		document.member_form.addr2.focus();
		return;
	}
	
	if(!document.member_form.hp2.value || !document.member_form.hp3.value){
		alert("휴대폰 번호를 입력하세요");
		document.member_form.hp2.focus();
		return;
	}
	if(!document.member_form.email1.value || !document.member_form.email2.value){
		alert("이메일 주소를 입력하세요");
		document.member_form.email1.focus();
		return;
	}
	
	if(!document.member_form.year.value || !document.member_form.month.value || !document.member_form.day.value){
	alert("생년 월일을 입력하세요");
	document.member_form.year.focus();			
	}
		
	
	if(document.member_form.pass.value != document.member_form.pass_confirm.value){
		 alert("비밀번호가 일치하지 않습니다.\n 다시 입력해주세요.");
		document.member_form.pass.focus();
		document.member_form.pass.select();
		return;
	}	
	
	if(!document.member_form.sign1.value || !document.member_form.sign2.value){
		alert("이용약관 및 개인정보수집에 동의하십시오");
		document.member_form.sign1.focus();
		return;
	}
	
	if(document.member_form.sign1.value == "deagree" || document.member_form.sign2.value == "deagree" ){
		alert("이용약관 및 개인정보 수집에 동의하십시오.");
		document.member_form.sign1.focus();
		return;
	}
			
	document.member_form.submit();
}

function checkemailaddy(){
		 
        if (document.member_form.email3.value == "") {
        	document.member_form.email2.readOnly=false;
        	document.member_form.email2.focus();
        	document.member_form.email2.value = '';
        	return;
        }
        else { 
		document.member_form.email2.readOnly = true;        	
       	document.member_form.email2.value = document.member_form.email3.value;
        return;
        }
    } 
	

    function sample6_execDaumPostcode() {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullAddr = ''; // 최종 주소 변수
                var extraAddr = ''; // 조합형 주소 변수

                // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    fullAddr = data.roadAddress;

                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    fullAddr = data.jibunAddress;
                }

                // 사용자가 선택한 주소가 도로명 타입일때 조합한다.
                if(data.userSelectedType === 'R'){
                    //법정동명이 있을 경우 추가한다.
                    if(data.bname !== ''){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있을 경우 추가한다.
                    if(data.buildingName !== ''){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
                    fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('sample6_postcode').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('sample6_address').value = fullAddr;

                // 커서를 상세주소 필드로 이동한다.
                document.getElementById('sample6_address2').focus();
            }
        }).open();
    }
</script>

</head>
<body>
	<div id="wrap">
		
		<div id="menu">
		
		</div>
		<!-- end of menu -->
		<div id="content">
			<div id="col1">
				
			</div>
			<!-- end of col1 -->

			<div id="col2">
				<form name="member_form" method="post" action="insert.php">
					<div id="title">
						<img src="../img/title_join.jpg">
					</div>
					<!-- end of title -->

					<div id="form_join">
						<div id="join1" style="height:314px;">
							<ul>
								<li>* 아이디</li>
								<li>* 비밀번호</li>
								<li>* 비밀번호 확인</li>
								<li>* 이름</li>
								<li style="height:40px;">* 주소</li>
								<li style="margin-top:8px;">* 휴대전화</li>
								<li>* 이메일</li>
								<li style="margin-top:3px;">* 생년월일</li>
								
							</ul>
						</div>
						<div id="join2" style="height:320px;">
							<ul>
								<li>
								<div id="id1">
										<input type="text" name="id" id="id">									
				
										<a href="#"><img src="../img/check_id.gif"
										onclick="check_id()"></a>								
								</div>
									<div id="id2">(영문소문자/숫자, 4-16자)</div>
								</li>
								<li>
								<div id="pw1" ><input type="password" id="password1" name="pass"
								onblur="check_password1();" style="margin-bottom:5px;" maxlength="16">
								</div>
								<div id="pw2" style="margin-left:5px; margin-top:5px;">&nbsp;(영문 대소문자/숫자 사용가능, 8-16자)</div>
								</li>
								
								<li><input type="password" id="password2" name="pass_confirm" onchange="check_password2();" style="float:left;"><p id="password_text"></p></li>
								
																
								<li><input type="text" name="name"></li>
							
								<li style="height:55px;">
								<div id="addr"  style="float:left;">
								<input type="text" id="sample6_postcode" name="post"placeholder="우편번호"
								 style="width:80px; margin-right: 5px;" readonly></div>
								<div>
								<input type="button" onclick="sample6_execDaumPostcode()" value="우편번호" 
								style="width:70px; height:20px; margin-bottom:5px;"></div>
								
								<div style="float:left;">
								<input type="text" id="sample6_address" name="addr1"placeholder="주소" readonly></div>
								<div style="float:left; margin-left: 5px;">
								<input type="text" name="addr2" id="sample6_address2" placeholder="상세주소"></div>
								</li>
								<li><div id="tel">					
								<select class="hp" name="hp1" id="hp1">
										<option value='010'>010</option>
										<option value='011'>011</option>
										<option value='016'>016</option>
										<option value='017'>017</option>
										<option value='018'>018</option>
										<option value='019'>019</option>
								</select>
								 <p style="float: left;">-</p><input type="text" class="hp" name="hp2" id="hp2" >
								 <p style="float: left;">-</p>
								 <input type="text" class=" hp" name="hp3" id="hp3" onblur="check_tel();"><p id="hp_text"></p>
									</div>	
								</li>
									
								
								<li><input type="text" id="email1" name="email1">@<input type="text" id="email2" name="email2" readOnly>
									<select class="email" name="email3" id="email3"  onChange="checkemailaddy();">
										<option value='이메일선택' disabled>--이메일 선택--</option>
										<option value='naver.com'>naver.com</option>
										<option value='hanmeil.net'>hanmail.net</option>
										<option value='gmail.com'>gmail.com</option>
										<option value='nate.com'>nate.com</option>
										<option value='yahoo.com'>yahoo.com</option>
										<option value=''>직접입력</option>
												
									</select>
								</li>
								<li><input type="text" class="year" name="year" style="width:60px;">년&nbsp;&nbsp;<input type="text" class="month" name="month" style="width:45px;">월
								&nbsp;<input type="text" class="day" name="day"style="width:45px;">일						
								</li>
									
							</ul>
						</div>
						<div class="clear"></div>
						
					</div>
					
					<div id="title2">
						<img src="../img/title_join2.jpg">
					</div>
					<div id="form_join2">
						<div id="join3">
							
							<div>
							<?php 
							include '../include/member_agree.php';
							?>
							</div>							
					&nbsp;&nbsp;&nbsp;&nbsp;이용약관에 동의하십니까?
					<input type="radio" name="sign1" 동value="agree">의			
					<input type="radio" id="deagree1" name="sign1" value="deagree">동의안 함				
					</div>
					</div>
					
					<div id="form_join3">
						<img src="../img/title_join3.jpg" style="margin-bottom:10px">
							<div id="join4">
							<?php 
							include '../include/member_agree2.php';
							?>
							</div>
							&nbsp;&nbsp;&nbsp;&nbsp;개인수집 및 이용 동의에 동의하십니까?
					<input type="radio" name="sign2" value="agree">동의			
					<input type="radio" id="deagree2" name="sign2" value="deagree">동의안 함			
					</div>
					
				<div id="button">
						<a href="#"><img src="../img/member_save.jpg"
							onclick="check_input()"></a>&nbsp;&nbsp; <a href="../../newfile.php"><img
							src="../img/cancel.jpg"></a>
					</div>
					
					
				</form>
			</div>
			<!-- emd of col2 -->
		</div>
		<!-- end of content -->
	</div>
	<!-- end of wrap -->
</body>
</html>
