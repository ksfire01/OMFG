<?php 
    session_start();
    include "../lib/dbconn.php";
    include '../../top/top.php'; 
 ?>
	
<html>
<head>
<meta charset="utf-8">
<link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../css/board.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/board_list.css" rel="stylesheet" type="text/css" media="all">
 
<style type="text/css">
        .container#body{
            position: relative;
            width: 1000rem;
            top: 5rem;
        }
        #wrap{
            position: relative;
            top: 100px;
        }
#new-arrival{
            font-family: "Century Gothic";
            font-size: 2em;
            text-align: center;
            text-decoration: underline;
        }
        footer{
            position: relative;
            top: 7rem;
        }
</style>
</head>
  
  <?php
    $userid = $_SESSION['userid'];
    $scale=4;  //한 화면에 표시되는 글의 개수
    
    $table = "notice";
    
    $mode=isset($_GET['mode']) ? $_GET['mode'] : "";
    if($mode=="search")
    {
        /* if(!$search)
        {
          echo("
            <script>
                window.alert('검색할 단어를 입력해 주세요!');
                history.go(-1)
           </script>
            ");
           exit;
        } */
     $sql ="select * from notice where $find like '%$search%' order by num desc";
     
    }
    else if(!isset($find)){
        $sql="select * from notice order by num desc";
        
    }else
    {
        $sql="select * from notice order by num desc";
    }
    
    $result=mysqli_query($con, $sql);
    $total_record = mysqli_num_rows($result); // 전체 글의 개수
    
    // 전체 페이지 수($total_page) 계산
    
    if($total_record % $scale==0){
        $total_page=floor($total_record/$scale);
    }else{
        $total_page=floor($total_record/$scale) + 1;
    }
           
     if(empty($page))
       $page=1;  //페이지 번호가 0일 때 페이지 번호를 1로 초기화(맨 처음 페이지)
        // 표시할 페이지($page)에 따라 $start 계산
         $start = ($page-1) * $scale; // 각 페이지 글 시작 위치
         $number = $total_record - $start; // 선택한 페이지 시작번호
?>  
 <body>
	<div class="container" id="body">
<div class="col-md-12">
	<p id="new-arrival">N O T I C E</p>
</div>
		
<div id="list_top_title">
	<ul>
		<li id="list_title1"><img src="../img/list_title1.gif"></li>
		<li id="list_title2"><img src="../img/list_title2.gif"></li>
		<li id="list_title4"><img src="../img/list_title4.gif"></li>
		<li id="list_title5"><img src="../img/list_title5.gif"></li>
	</ul>
</div>
	

<div id="list_content">
  <?php 
     for($i = $start ; $i<$start+$scale && $i<$total_record ; $i++)
    {
        //가져올 레코드로 위치(포인터) 이동
        mysqli_data_seek($result, $i);
        
        //하나의 레코드 가져오기
        
        $row = mysqli_fetch_array($result);
        $item_num = $row['num'];
        $item_subject = str_replace(" ", "&nbsp;" , $row['subject']);
        $item_date = $row['regist_day'];
        $item_date = substr($item_date, 0, 10);
        $item_hit = $row['hit'];
 ?>
 <div id="list_item">
 <div id="list_item1"><?=$item_num?></div>
 <div id="list_item2"><a href="board_view.php?table=<?=$table?>
 &num=<?=$item_num?>&page=<?=$page?>"><?=$item_subject?></a></div>
 <div id="list_item4"><?=$item_date?></div>
 <div id="list_item5"><?=$item_hit?></div>
 </div>
 <?php
    $number--;
    } 
 ?>
 	<div id = "page_num">
 		
  <?php
  $page_block=3;  // 한 블럭에 표시되는 페이지 개수
  
  $total_block = ceil($total_page / $page_block);  // 전체 블럭의 값
  $block = ceil($page / $page_block);  // 현재 페이지의 블럭 값
  $first = ($block - 1) * $page_block;  // 현재 블록의 첫 페이지 위치
  $last = $block * $page_block;  // 현재 블록의 마지막 페이지 위치
  
  if($block >= $total_block){  // 현재 블록이 마지막 위치라면
      $last = $total_page;  // 마지막 페이지는 전체 페이지의 값과 동일하다.
  }
  if($block >1){  // 현재 블록이 1보다 크면(블록값이 2일 때 부터)
      echo "[<a href ='board_list.php?page=1'> ← </a>]&nbsp;&nbsp;";  
  }  //[처음] 이 뜨도록 함
 
  for($page_link = $first+1; $page_link <= $last; $page_link++){   // 블럭 안에 페이지 넣기
      
      if($page_link == $page){  // 현재 페이지는 링크 없이 빨간색으로 표시
          echo " <font color='red'><b> {$page_link}</b></font> &nbsp;";
      }else{  // 나머지 페이지는 링크걸기
          echo "<a href ='board_list.php?page=$page_link'>$page_link</a>&nbsp;";
      }
  }
 
  if($block < $total_block){
      echo "&nbsp;&nbsp;[<a href='board_list.php?page=$total_page'> → </a>]";
  }
   
  
  
      /* for($i=1; $i<=$total_page; $i++){
        if($page==$i)  //현재 페이지 번호 링크 안함
        {
          echo "<b>$i&nbsp;&nbsp;</b>";
        }else{
            echo "<a href='board_list.php?table=$table&page=$i'>$i&nbsp;&nbsp;</a>";
        }
     } */
     
?>
</div>
</div>
<!-- 여기까지 페이지 구성 및 이동 기능 구현 -->
		 
 <form name="board_form" method="post" action="board_list.php?mode=search">
	<div id="list_search1" style="float:left; margin-left: 35px;">
		<img src="../img/search_list.jpg"> &nbsp; &nbsp;
	</div>		
	<div id="list_search2" style="float:left;">
		<select name="find" style="height: 23px; font-size: 13px;">
			<option value='subject'>제목</option>
			<option value='content'>내용</option>		
		</select>
		&nbsp;
	</div><!--end of list_search2 -->
	
		<div id="list_search3" style="float:left;">
		<input type="text" name="search" style="height: 24px;">&nbsp;&nbsp;		
		</div>
	
		<div id = "list_search4" style="float:left">
			<input type="image" src="../img/search_button.jpg"></div>
		</form>			
		<div id = "write" style="float:left; margin-left: 375px; margin-top: 10px;">
		<a href="board_list.php?table=<?=$table?>&page=<?=$page?>">
 		<img src="../img/list.jpg"></a>
		<?php
		if($userid=="admin")
		{
		?>
			<a href = "./write_form.php?table=<?=$table?>&page=<?=$page?>"><img src ="../img/write.jpg"></a>
			<?php 
		}
		?>
		</div>		
	</div><!-- end of content -->
	</body>
	<?php if(isset($_SESSION['userid'])&&$_SESSION['userid']=="admin") include '../../top/manager_nav.php';?>
<footer class="text-muted">
	<img src="../../img/footer.jpg" style="width: 100%; height: 30rem;">
  </footer> 
 </html>