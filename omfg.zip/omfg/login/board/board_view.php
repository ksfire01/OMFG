<?php
    session_start();
    include "../lib/dbconn.php";
    include "../../top/top.php";
    
    $sql = "select * from notice where num=$num";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
    
    $list_num = $row['num'];
    $list_subject = $item_subject = str_replace(" ","&nbsp;", $row['subject']);
    $list_content= $row['content'];
    $list_hit = $row['hit'];
    $list_date = $row['regist_day'];
    
    $hit = $list_hit +1;
    $sql = "update notice set hit = $hit where num=$num";
    mysqli_query($con, $sql);
 ?>
 <html>
 <head>
 <meta charset ="utf-8">
 <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
 <link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
 <link href="../css/board.css" rel="stylesheet" type="text/css" media="all">
 <link href="../css/board_view.css" rel="stylesheet" type="text/css" media="all">
 <style type="text/css">
        .container#body{
            position: relative;
            width: 200rem;
            top: 5rem;
        }
        #wrap{
            position: relative;
            top: 100px;
        }
        footer{
            position: relative;
            top: 20rem;
        }
        #new-arrival{
            font-family: "Century Gothic";
            font-size: 2em;
            text-align: center;
            text-decoration: underline;
        }
</style>
 </head>
 <body>
 	<div class="container" id="body">
 	<div id="content_main">
<div class="col-md-10">
	<p id="new-arrival">N O T I C E</p>
</div>
		
		<div id="view_content">
			<div id="view_subject1">제목</div>
			<div id="view_subject2"><?=$list_subject?></div><br>
			<div id="view_date1">작성일</div>
			<div id="view_date2"><?=$list_date?></div>
			<div id="view_hit1">조회수</div>
			<div id="view_hit2"><?=$list_hit?></div><br>
			<div id="content1"><?=$list_content?></div>		
		</div>
		
		<div id="view_button">
	<a href="board_list.php?table=notice&page=<?=$page?>"><img src="../img/view_list.jpg"></a>&nbsp;
	<a href="write_form.php?table=<?=$table?>&mode=modify&num=<?=$list_num?>&page=<?=$page?>"><img src="../img/view_modify.jpg"></a>&nbsp;
	
	<a href="delete_board.php?table=notice&page=<?=$page?>&num=<?=$list_num?>"><img src="../img/delete_board.jpg"></a>
 	</div> <!-- end of content_main -->
 	</div>
 	
 </div>
 </body>
 <footer class="text-muted">
	<img src="../../img/footer.jpg" style="width: 100%; height: 30rem;">
  </footer>
 </html>