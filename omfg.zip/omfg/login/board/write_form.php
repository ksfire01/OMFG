<?php
    session_start();
    include '../lib/dbconn.php';
    include  '../../top/top.php';
    if(!isset($_SESSION['userid'])||!$_SESSION['userid']=="admin"){
        echo "<script>alert('관리자 아이디로 로그인 해주시기 바랍니다.'); history.back();</script>";
    }
    $mode = isset($_GET['mode']) ? $_GET['mode'] : "";
    $table = "notice";
    
    if($mode=="modify")
    {
        $sql = "select * from $table where num = $num";
        $result= mysqli_query($con, $sql);
        $row = mysqli_fetch_array($result);
        
        $subject = $row['subject'];
        $content = $row['content'];   
    }  
    
    ?>

<html>
 <head>
 <meta charset="utf-8">
 <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
 <link href="../css/board.css" rel="stylesheet" type="text/css" media="all">
 
 <style type="text/css">
        .container#body{
            position: relative;
            width: 1000rem;
            top:100px;
        }
        #wrap{
            position: relative;
            top: 100px;
        }
 </style>
 <script>
 	function check_input(){
 		if(!document.board_form.subject.value){
 			alert("제목을 입력하세요");
 			document.board_form.subject.focus();
 			return;
 		}
 		if(!document.board_form.content.value){
 			alert("내용을 입력하세요");
 			document.board_form.content.focus();
 			return;
 		}
 		document.board_form.submit();
 	}
  </script> 
 </head>
 <body>
 	<div class="container" id="body">
 	<div class="header">
          <div class="container">
            <h2>공지사항작성</h2>
          </div>
    </div>
	<div id="content_main">

		<div id="content">		
		<?php 
		  if($mode == "modify")
		  {
		?>
		<form name="board_form" method ="post" action="insert.php?mode=modify&num=<?=$num?>&page=<?=$page?>&table=<?=$table?>"
		enctype="multipart/form-data">
		<?php 
		  }
		  else
		  {
    	?>
    	 <form name="board_form" method="post" action="insert.php?table=<?=$table?>"enctype="multipart/form-data">
     	<?php 
      }
     ?>
     <div id="write_form">
    	<div id ="write_subject">
    	<div id = "col1" style="float:left; margin-right: 20px;">제목</div>
    	<div class="col2"><input type="text" name="subject" value="<?=($mode=="modify") ? $subject:""?>"></div>    	
    	</div>
    	
    	<div id="write_content"><div class="col1" style="margin-bottom: 10px;">내용</div>
		<div class="col2"><textarea rows="15" cols="79" name="content">
		<?=($mode=="modify")?$content : ""?></textarea></div>
		</div>
		<div id="write_button" style="margin-top: 10px; margin-left: 470px;"><a href="#">
		<img src="../img/write_ok.jpg" onclick ="check_input();"></a>&nbsp;
    	<a href="board_list.php?table=<?=$table?>&page=<?=$page?>"><img src ="../img/list.jpg"></a>
    	</div>
	</div><!-- end of write_form -->
	</form>
		</div><!-- end of content -->
	</div> <!-- end of content_main -->
	</div>
	<?php include '../../top/manager_nav.php'?>
	</body>
	</html>