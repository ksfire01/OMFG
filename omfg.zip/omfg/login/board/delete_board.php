<?php
    session_start();
    include "../lib/dbconn.php";
    include"../../top/top.php";
    
    $sql = "select * from notice where num=$num";
    $result=mysqli_query($con, $sql);
    $row =mysqli_fetch_array($result);
    
    
    $sql = "delete from notice where num=$num";
    mysqli_query($con, $sql);
    
    mysqli_close($con);
    
    echo ("
        <script>
            location.href='board_list.php?table=notice';
        </script>
    ");
   ?>