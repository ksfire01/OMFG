<?php
include "../lib/dbconn.php";

$flag = "NO";  // 어떤 기능을 no, yes에 따라 실행하는지 여부를 결정한다.

$sql = "SHOW TABLES FROM shopDB";
$result = mysqli_query($con, $sql);
if (!$result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: '.mysqli_error();
    exit;
}

while ($row = mysqli_fetch_row($result)) {
    if($row[0]=="notice")
    {
        $flag = "OK";
        break;
    }
}


/* 테이블이 존재하지 않으면 테이블생성  */
if($flag != "OK")
{
    $sql = "create table notice (
                num int not null auto_increment,
                subject varchar(100) not null,
                content text not null,
                regist_day varchar(20),
                hit int,
                primary key(num))";
    
    /*테이블 생성하고 쿼리문 실행  */
    $result = mysqli_query($con, $sql) or die	("<font size=4><br><center>notice table은 이미 존재함</font><hr>
    <script>
		alert('[존재하는 테이블임] notice 존재함; ');
    </script>"); // 여기까지 die문
}
echo "<font size=4><br><center>notice 성공적으로 만듬</font><hr>";
echo "<script>
        alert('[테이블생성성공] notice 테이블 생성');
		</script>";
mysqli_close($con); //db연결 종료
?>