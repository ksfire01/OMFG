<?php
session_start();
include "../lib/dbconn.php";

$mode = isset($_GET['mode']) ? $_GET['mode'] : "" ; 

$subject = $_POST['subject'];
$content = $_POST['content'];
$regist_day = date("Y-m-d(H:i)");
?>

<?php 
if(isset($mode) && $mode=="modify")
{
    $sql = "select * from notice where num=$num";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
    
    $sql = "update notice set subject ='$subject', content='$content' where num=$num";
    mysqli_query($con, $sql);
    
}else {
  
  $content=htmlspecialchars($content);
  $sql ="insert into notice(subject, content, regist_day)values('$subject', '$content', '$regist_day')";
    mysqli_query($con, $sql);

    echo("
    <script>
        location.href='board_list.php?table=notice&page=$page';
    </script>
");
    
}
mysqli_close($con);


echo("
    <script>
        location.href='board_list.php?table=notice&page=$page';
    </script>
");
?>
