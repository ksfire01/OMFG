<?php
@extract($_POST);//extract() : 배열속의 키값들을 변수화를 진행하는 함수
@extract($_GET);
@extract($_FILES);
@extract($_COOKIE);
@extract($_SESSION);
@extract($_SERVER);
@extract($_ENV);
?>

<?php
    $con = mysqli_connect("localhost","root","123456","shopDB") or die("SQL server에 연결할 수 없습니다.");
    
    $page_line = 4;  // 한 페이지에 보여지는 글의 개수
    $page_block= 3;  // 한 블럭 당 페이지 링크 개수
    
?>