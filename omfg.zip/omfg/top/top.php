<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="/homepage/omfg/bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <style type="text/css">
        .navbar{
            max-height: 100px;
            min-width: 100%;
        }
        a.nav-link{
            color: black;
            font-size: medium;   
        }
        a.nav-link:hover{
            color: gray;
        }
        a.navbar-brand{
            color: black;
        }
        #navbrand{
            
        }
        .navbar-nav#menu1{
            
            align-content: center;
            align-items: center;
            padding-top: 45px;
        }
        .navbar-nav#menu2{
            
            align-content: right;
            align-items: right;
            padding-top: 45px;
            
        }
        .navbar-brand#logo{
            
            font-family: "Century Gothic";
            font-size: 4em;
            font-weight: bolder;
            font-style: italic;
            text-align: center;
            color: black;
            text-decoration: none;
        }
        h1{
            color: black;
        }
        
        .header{
            margin-bottom: 0rem;
        }

            text-align: center;
        }
      
     </style>
     </head>
     <body>
     <nav class="navbar navbar-expand-lg fixed-top bg-white d-block">
   <!--    <a class="navbar-brand" href="#">Carousel</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      <div class="collapse navbar-collapse" id="navbarCollapse">
      <div class="container" id="top-menu">
      	<div class="row">
      	<div class="col-md-5">
        <ul class="navbar-nav mr-auto justify-content-start" id="menu1">
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/product/suitlist.php?type=o">OUTER</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/product/suitlist.php?type=t">TOP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/product/suitlist.php?type=b">BOTTOM</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/product/suitlist.php?type=s">SHOES/BAG</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/product/suitlist.php?type=a">ACC</a>
          </li>
        </ul>
        </div>
        <div class="col-md-2 justify-content-center" id="navbrand">
        <a class="navbar-brand" href="/homepage/omfg/newfile.php" id="logo">OMFG</a>
        </div>
        <?php 
        if(isset($_SESSION['userid'])){
        ?>
        <div class="col-md-5">
        <ul class="navbar-nav mr-auto justify-content-end" id="menu2">
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/logout.php">LOGOUT</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/board/board_list.php">NOTICE</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/cart/cart.php">CART</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/cart/my_buy.php">ORDER</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/member_form_modify.php">MY PAGE</a>
          </li>
        </ul>
        </div>
        <?php 
        }else{
        ?>
        <div class="col-md-5">
        <ul class="navbar-nav mr-auto justify-content-end" id="menu2">
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/login_form.php">LOGIN</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/member/member_form.php">JOIN US</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/board/board_list.php">NOTICE</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/login_form.php">CART</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/login_form.php">ORDER</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/homepage/omfg/login/login/login_form.php">MY PAGE</a>
          </li>
        </ul>
        </div>        
        
        <?php 
        }
        ?>
        
      </div>
      </div>
    </nav>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
	</body>
</html>