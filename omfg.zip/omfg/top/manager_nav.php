<?php
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <style>
  	.navbar#bottom{
  		min-height: 50px;
  	}
  </style>
  </head>
  <body>
 
<nav class="navbar navbar-expand-lg fixed-bottom navbar-dark bg-dark" id="bottom">
  <a class="navbar-brand" href="#">관리자 메뉴</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="/homepage/omfg/manager/product_insert_form.php">상품등록 </a>
      <a class="nav-item nav-link" href="/homepage/omfg/manager/product_manage.php">상품관리</a>
      <a class="nav-item nav-link" href="/homepage/omfg/manager/order_manage.php">주문관리</a>
      <a class="nav-item nav-link" href="/homepage/omfg/manager/manager_graph.php">관리자차트</a>
      <a class="nav-item nav-link" href="/homepage/omfg/login/board/write_form.php">공지사항작성</a>
      <a class="nav-item nav-link" href="/homepage/omfg/manager/email/sample.php">이메일 작성</a>
    </div>
  </div>
</nav>
</body>
</html>