<?php
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$mode=isset($_GET['mode'])?$_GET['mode']:"";
$page=isset($_GET['page'])?$_GET['page']:1;
$block=isset($_GET['block'])?$_GET['block']:1;
if($mode=="search"){
    if($_GET['search-type']=="userid"){
        $sql="select * from order_list_tb where userid like '%".$_GET['search-text']."%' order by order_num desc";
        $orderlist_result=mysqli_query($con, $sql) or die(mysqli_error($con));
        
    }else if($_GET['search-type']=="order_day"){
        $sql="select * from order_list_tb where order_day='".$_GET['search-text']."' order by order_num desc";
        $orderlist_result=mysqli_query($con, $sql);
        
    }else if($_GET['search-type']=="state"){
        $sql="select * from order_list_tb where state='".$_GET['search-text']."' order by order_num desc";
        $orderlist_result=mysqli_query($con, $sql);
    }
}else{
    $sql="select * from order_list_tb order by order_num desc";
    $orderlist_result=mysqli_query($con, $sql);
    
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <link href="./carousel.css" rel="stylesheet">
     <style type="text/css">
     .container#top-menu{
            border-bottom-color: black;
            border-bottom-style: solid;
            border-bottom-width: 8px;
            
        }
     .container#body{
            position: relative;
            top: 8rem;
            width: 100rem;
            margin-bottom: 10rem;
        }
      h3{
        font-weight: bolder;
      }
      #cell1{
            background-color: rgb(60, 60, 60);
            text-align: center;
            color: white;
            border-color: white;
            border-style: solid;

      }
      #cell2{
        background-color: rgb(230, 230, 230);
        text-align: center;
        border-color: white;
        border-style: solid;
      }
      #pagination{
        
      }
     </style>
     <script type="text/javascript">
    	function pickdate(){
    		if(document.getElementById("search").value=="order_day"){
    		document.getElementById("search_form_group").innerHTML=
    			"<input type='hidden' value='search' name='mode'>"+
    			"<select class='form-control' id='search' name='search-type' required>"+
            	"<option value='order_day' onselect='pickdate()'>주문날짜</option>"+
            	"<option value='product_name'>제품명</option>"+
            	"<option value='product_type'>제품유형</option>"+
            	"<option value='userid'>아이디</option>"+
          		"</select>"+
          		"<input type='date' class='form-control' name='search-text'>"+
          		" <div class='input-group-btn'>"+
          		"<button class='btn btn-default' type='submit'>검색</button></div>";
    		}else{
    			
    		}
    	}
     	function update_state(i, order_num){
     		var xhttp = new XMLHttpRequest();
     		xhttp.onreadystatechange = function(){
     			if(this.readyState==4 && this.status == 200){
     				document.getElementById("state"+i).innerHTML = this.responseText;
     			}
     		};
     		
     		xhttp.open("GET", "update_order.php?order_num="+order_num+"&changed_state="+document.getElementById("changed_state"+i).value, true);
     		xhttp.send();
     		
     	}
    	
    </script>
     </head>
  <body>
  
   <?php include '../top/top.php';
   if(!isset($_SESSION['userid'])||!$_SESSION['userid']=="admin"){
       echo "<script>alert('관리자 아이디로 로그인 해주시기 바랍니다.'); history.back();</script>";
   }
   ?> 
	<div class="container" id="body">
		<div class="header">
          <div class="container">
          <div class="row">
          <div class="col-md-6">
            <h2>주문관리</h2>
            </div>
            
          <div class="col-md-6">
                <div class="col-md-12">
                <form action="order_manage.php" method="get">
                  <div class="input-group" id="search_form_group">
                  	<input type="hidden" value="search" name="mode">
                    <select class="form-control" id="search" name="search-type" required>
                      <option value="userid">아이디</option>
                      <option value="order_day">주문날짜</option>
                      <option value="state">배송상태</option>
                    </select>
                    <input type="text" class="form-control" name="search-text" placeholder="Search">
                    <div class="input-group-btn">
                      <button class="btn btn-default" type="submit">
                        	검색
                      </button>
                    </div>
                  </div>
                  </form>
                </div>
          </div>
          </div>
          </div>
        </div>
        
        <div class="container">
        
<?php

$content_per_page=5;
$total_rows=mysqli_num_rows($orderlist_result);
$start_index=($page-1)*5;
$total_pages=ceil($total_rows/$content_per_page);
if($page==$total_pages){
    $content_per_page=$total_rows-$start_index;
}
for($i=$start_index;$i<$start_index+$content_per_page;$i++){
    mysqli_data_seek($orderlist_result, $i);
    $row=mysqli_fetch_array($orderlist_result);
    
    
?>
       		<div class = "card">
        		<div class = "card-header">
        			<div class="row">
        				<div class="col-md-8"><div class="row"> <h3><?=$row['order_num'] ?> :</h3><h3 id="<?php echo "state".$i?>"> <?=$row['state'] ?></h3></div></div>
        				<div class="col-md-4">
        					<div class="input-group">
        						<select class="form-control" id="<?php echo "changed_state".$i ?>" name="search-type" required>
                      				<option value="주문접수중">주문접수중</option>
                      				<option value="배송준비중">배송준비중</option>
                      				<option value="배송중">배송중</option>
                      				<option value="배송완료">배송완료</option>
                    			</select>
                    			<div class="input-group-btn">
                      				<button class="btn btn-default" onclick="update_state(<?=$i?>, '<?=$row['order_num']?>')">
                        				배송상태변경
                      				</button>
                    			</div>
        					</div>	
        				</div>
        			</div>
        		</div>
        		
        	<div class = "card-body">
        	<div class="row">
        		<div class="col-md-2">
        			<div class="row">
        				<div class="col" id="cell1">
        				주문자아이디
        				</div>
        			</div>
        			<div class="row">
        				<div class="col" id="cell2">
        				<?=$row['userid'] ?>
        				</div>
        			</div>
        		</div>
        		<div class="col-md-2">
        			<div class="row">
        				<div class="col" id="cell1">
        				받는사람
        				</div>
        			</div>
        			<div class="row">
        				<div class="col" id="cell2">
        				<?=$row['receiver'] ?>
        				</div>
        			</div>
        		</div>
        		<div class="col-md-8">
        			<div class="row">
        				<div class="col" id="cell1">
        				주소
        				</div>
        			</div>
        			<div class="row">
        				<div class="col" id="cell2">
        				<?=$row['address'] ?>
        				</div>
        			</div>
        		</div>
        		</div>
        		<div class="row">
        			<div class="col-md-12" id="cell1">
        				배송메세지
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-md-12" id="cell2">
        				<?=$row['message'] ?>
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-md-4" id="cell1">
        				주문날짜
        			</div>
        			<div class="col-md-4" id="cell1">
        				전화번호
        			</div>
        			<div class="col-md-4" id="cell1">
        				결제수단
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-md-4" id="cell2">
        				<?=$row['order_day'] ?>	
        			</div>
        			<div class="col-md-4" id="cell2">
        				<?=$row['phone'] ?>
        			</div>
        			<div class="col-md-4" id="cell2">
        				<?=$row['pay_method'] ?>
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-md-4" id="cell1">
        				제품명
        			</div>
        			<div class="col-md-2" id="cell1">
        				사이즈
        			</div>
        			<div class="col-md-2" id="cell1">
        				색상
        			</div>
        			<div class="col-md-2" id="cell1">
        				수량
        			</div>
        			<div class="col-md-2" id="cell1">
        				가격
        			</div>
        		</div>
        		<?php 
        		  $sql="select * from buytbl where order_num='".$row['order_num']."'";
        		  $res2=mysqli_query($con, $sql);
        		  while($row2=mysqli_fetch_array($res2)){
        		  
        		?>
        		<div class="row">
        			<div class="col-md-4" id="cell2">
        				<?php echo explode("-", $row2['product_code'])[0] ?>
        			</div>
        			<div class="col-md-2" id="cell2">
        				<?php echo $row2['size']?>
        			</div>
        			<div class="col-md-2" id="cell2">
        				<?php echo $row2['color']?>
        			</div>
        			<div class="col-md-2" id="cell2">
        				<?php echo $row2['buy_quantity']?>
        			</div>
        			<div class="col-md-2" id="cell2">
        				<?php echo $row2['buy_price']?>
        			</div>
        		</div>
        		<?php 
        		  }
        		?>
        		
        	</div>
        	</div>
<?php 
}
?>
        
	</div>
	</div>
	<nav id="pagination" aria-label="Page navigation example">
          <ul class="pagination justify-content-center">
          <?php 
                $pages_per_block=5;
                $total_blocks=ceil($total_pages/$pages_per_block);
                $start_page=($block-1)*$pages_per_block+1;
                if($block==$total_blocks){
                    $pages_per_block=$total_pages-$start_page;
                }
                if($block>1){
                    ?>
			<li class="page-item"><a class="page-link" href=<?php echo "/homepage/omfg/manager/order_manage.php?page=".($start_page-1)."&block=".$block-1?>>Previous</a></li>
                    <?php
                }
                
                for($i=$start_page;$i<=$start_page+$pages_per_block;$i++){
                    echo "<li class='page-item'><a class='page-link' href='/homepage/omfg/manager/order_manage.php?page=$i&block=$block'>$i</a></li>";
                }
                
                if($block<$total_blocks){
                    echo "<li class='page-item'><a class='page-link' href='/homepage/omfg/manager/order_manage.php?page=".$start_page+$pages_per_block."&block=".($block+1)."'>Next</a></li>";
                }
              
              ?>
           		
            
          </ul>
        </nav>
		<?php include '../top/manager_nav.php';?>
	    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>