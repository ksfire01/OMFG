<?php
$i=$_GET['i'];
$j=$_GET['j'];
$product_code = stripslashes($_GET['product_code']);
$inventory_in = $_GET['inventory_in'];

$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql="update product_list_tb set inventory=inventory+$inventory_in, inventory_in=inventory_in+$inventory_in where product_code='$product_code'";
mysqli_query($con, $sql);
$sql="select color, size_name, inventory_in, inventory_out, inventory from product_list_tb where product_code='".$product_code."'";
$result=mysqli_query($con, $sql);
$row=mysqli_fetch_array($result);

$product_code1="'$product_code'";

echo "<div class='col-md-3' id='smallcol2'>".$row['color']."-".$row['size_name']."</div>";
echo "<div class='col-md-2' id='smallcol2'>".$row['inventory_in']."</div>";
echo "<div class='col-md-2' id='smallcol2'>".$row['inventory_out']."</div>";
echo "<div class='col-md-2' id='smallcol2'>".$row['inventory']."</div>";
echo "<div class='col-md-3' id='smallcol2'>";
echo "<div class='input-group input-group-sm'>";
echo "<input type='number' class='form-control' id='inventory_plus".$i."_".$j."'>";
echo "<span class='input-group-btn'>";
echo "<button class='btn btn-secondary' type='submit' onclick='plus_inventory(".$i.", ".$j.", ".$product_code.")'>확인</button>";
echo "</span></div></div>";

?>