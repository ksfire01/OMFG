<?php
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql="select product_type, sum(inventory_out*price) from product_list_tb group by product_type order by product_type";
$result=mysqli_query($con, $sql);
mysqli_data_seek($result, 0);
$row=mysqli_fetch_array($result);
$acc=$row['sum(inventory_out*price)'];
mysqli_data_seek($result, 1);
$row=mysqli_fetch_array($result);
$bottom=$row['sum(inventory_out*price)'];
mysqli_data_seek($result, 2);
$row=mysqli_fetch_array($result);
$outer=$row['sum(inventory_out*price)'];
mysqli_data_seek($result, 3);
$row=mysqli_fetch_array($result);
$shoes=$row['sum(inventory_out*price)'];
mysqli_data_seek($result, 4);
$row=mysqli_fetch_array($result);
$top=$row['sum(inventory_out*price)'];
include_once '../top/top.php';
if(!isset($_SESSION['userid'])||!$_SESSION['userid']=="admin"){
    echo "<script>alert('관리자 아이디로 로그인 해주시기 바랍니다.'); history.back();</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <style type="text/css">
     .navbar{
            border-bottom-color: black;
            border-bottom-style: solid;
            border-bottom-width: 8px;
            
        }
     .container#body{
            position: relative;
            top: 8rem;
            width: 120rem;
        }
     #donutchart{
        position: relative;
        right: 11rem;
     }
     #type_select{
        position: relative;
        left: 15rem;
        top: 2.5rem;
     }
     #barchart{
        margin-bottom: 5rem;
     }
     </style>
     <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
     <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.load('current', {'packages':['corechart', 'bar']});
      google.charts.setOnLoadCallback(drawChart1);
      google.charts.setOnLoadCallback(drawChart2);
      function drawChart1() {
        var data = google.visualization.arrayToDataTable([
          ['유형', '매출액'],
          ['OUTER',     parseInt(document.getElementById("outer").value)],
          ['TOP',      parseInt(document.getElementById("top").value)],
          ['BOTTOM',  parseInt(document.getElementById("bottom").value)],
          ['SHOES/BAG', parseInt(document.getElementById("shoes").value)],
          ['ACC',    parseInt(document.getElementById("acc").value)]
        ]);

        var options = {
          title: '제품유형별매출',
          pieHole: 0.4,
          titleTextStyle: {
        	  color : "black",
        	  bold : true,
        	  fontSize : 20,
          }
        };

        var chart1 = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart1.draw(data, options);
      }
      
      function drawChart2() {
    	  var data = new google.visualization.DataTable();

    	// Declare columns
    	data.addColumn('string', '제품명');
    	data.addColumn('number', '판매수량');
    	data.addColumn('number', '총매출');
		
            for(var i=0;i<document.getElementById("count1").value;i++){
            	data.addRows([
            		[document.getElementById("bar_product_name"+i).value,
            			parseInt(document.getElementById("bar_inventory_out"+i).value),
            			parseInt(document.getElementById("bar_money"+i).value)]
            		]);
            }

          var options = {
            chart: {
              title: '품목별매출',
              subtitle: '좌측 : 판매수량, 우측 : 매출',
            },
          	series: {
                0: {targetAxisIndex: 0},
                1: {targetAxisIndex: 1}
            },
            vAxes: {
              y: {
                  0: {title: '판매수량'},
                  1: {title: '매출'}
              }
            },
            titleTextStyle: {
          	  color : "black",
          	  bold : true,
          	  fontSize : 20,
            }
          	};

          var chart2 = new google.charts.Bar(document.getElementById('barchart'));

          chart2.draw(data, google.charts.Bar.convertOptions(options));
        }
      
   	function type_search(){
 		var xhttp = new XMLHttpRequest();
 		xhttp.onreadystatechange = function(){
 			if(this.readyState==4 && this.status == 200){
 				document.getElementById("column_data").innerHTML = this.responseText;
         		drawChart2();
 			}
 		};
 		
 		xhttp.open("GET", "bar_graph_type.php?product_type="+document.getElementById("search").value, true);
 		xhttp.send();
 		
 	}
   	
   	function combochart_send(){
   		var obj = {"period" : document.getElementById("period").value, 
   				   "start_date" : document.getElementById("start_date").value,
   				   "finish_date" : document.getElementById("finish_date").value}
   		var toServer = JSON.stringify(obj);
   		var xhttp = new XMLHttpRequest();
 		xhttp.onreadystatechange = function(){
 			if(this.readyState==4 && this.status == 200){
 				 var myObj = JSON.parse(this.responseText);
				drawChart3(myObj, obj.period)
 			}
 		};
 		
 		xhttp.open("GET", "combochart_db.php?incoming="+toServer, true);
 		xhttp.send();
   	}
   	
   	function drawChart3(obj, period){
   	 var data = new google.visualization.DataTable();

 	// Declare columns
 	data.addColumn('string', '기간');
 	data.addColumn('number', '총매출');
 	data.addColumn('number', 'OUTER');
 	data.addColumn('number', 'TOP');
 	data.addColumn('number', 'BOTTOM');
 	data.addColumn('number', 'SHOES/BAG');
 	data.addColumn('number', 'ACC');
 	if(period=="per_week"){
 	for(var x in obj){
    	data.addRows([
    		[obj[x].sales_period+"주", parseInt(obj[x].sales_total),
    		parseInt(obj[x].sales_outer), parseInt(obj[x].sales_top),
    		parseInt(obj[x].sales_bottom), parseInt(obj[x].sales_shoes), parseInt(obj[x].sales_acc)]
    		]);
    }
 	}else if(period=="per_month"){
 		for(var x in obj){
 	 	data.addRows([
    		[obj[x].sales_period+"월", parseInt(obj[x].sales_total),
    		parseInt(obj[x].sales_outer), parseInt(obj[x].sales_top),
    		parseInt(obj[x].sales_bottom), parseInt(obj[x].sales_shoes), parseInt(obj[x].sales_acc)]
    		]);
 		}
 	}else{
 		for(var x in obj){
 	 	 	data.addRows([
 	    		[obj[x].sales_period, parseInt(obj[x].sales_total),
 	    		parseInt(obj[x].sales_outer), parseInt(obj[x].sales_top),
 	    		parseInt(obj[x].sales_bottom), parseInt(obj[x].sales_shoes), parseInt(obj[x].sales_acc)]
 	    		]);
 	 		}
 	}

       var options = {
         vAxis: {title: '유형별매출액'},
         hAxis: {title: '기간'},
         seriesType: 'bars',
         series: {0: {type: 'line', targetAxisIndex: 1}},
         vAxis: {1: {title: '총매출액'}}
       }

       var chart = new google.visualization.ComboChart(document.getElementById('combochart'));
       chart.draw(data, options);
   	}
    </script>
     </head>
  <body>
  
   <?php 
   
   ?> 
	<div class="container" id="body">
		<div class="header">
          <div class="container">
            <h2>매니저 차트</h2>
          </div>
        </div>
        <div class="row">
        	<input type="hidden" id="outer" value=<?=$outer ?>>
        	<input type="hidden" id="top" value=<?=$top ?>>
        	<input type="hidden" id="bottom" value=<?=$bottom ?>>
        	<input type="hidden" id="shoes" value=<?=$shoes ?>>
        	<input type="hidden" id="acc" value=<?=$acc ?>>
        	<div class="col">
        		<div id="donutchart" style="width: 100%; height: 500px;"></div>
        	</div>
        </div>
        <div class="row">
        <div class="col-md-3" id="type_select">
        <div class="input-group">
        	<select class="form-control" id="search" name="">
        			  <option value="x">전체</option>	
                      <option value="o">OUTER</option>
                      <option value="t">TOP</option>
                      <option value="b">BOTTOM</option>
                      <option value="s">SHOES/BAG</option>
                      <option value="a">ACC</option>
			</select>
			<div class="input-group-btn">
                      <button class="btn btn-secondary" onclick="type_search()">
                        	GO!
                      </button>
			</div>
		</div>
		</div>
        </div>
        <div class="row">
        <div id="column_data">
        <?php 
        $sql="select product_name , sum(inventory_out), sum(inventory_out*price) from product_list_tb group by product_name";
        $res=mysqli_query($con, $sql);
        $count1=0;
        while ($row2=mysqli_fetch_array($res)){
        ?>
        	<input type="hidden" id=<?php echo "bar_product_name".$count1?> value=<?php echo $row2['product_name']?>>
        	<input type="hidden" id=<?php echo "bar_inventory_out".$count1?> value=<?php echo $row2['sum(inventory_out)']?>>
        	<input type="hidden" id=<?php echo "bar_money".$count1?> value=<?php echo $row2['sum(inventory_out*price)']?>>
        <?php
            $count1++;
        }
        ?>
        <input type="hidden" id="count1" value=<?php echo $count1?>>
        </div>
		<div class="col">
        		<div id="barchart" style="width: 100%; height: 500px;"></div>
        </div>
        </div>
        <div class="row">
        <div class="col-md-3">
        	<h5><b>기간별 매출</b></h5>
        </div>
        <div class="col-md-9">
        	<div class="row">
        	<div class="input-group">
        	<select class="form-control col-md-2" id="period" name="">	
        			  <option value="per_day">일간</option>
                      <option value="per_week">주간</option>
                      <option value="per_month">월간</option>
			</select>
			<input class="form-control" type="date" id="start_date" value="2017-09-09">
			<h5>&nbsp;&nbsp;~&nbsp;&nbsp;</h5>
			<input class="form-control" type="date" id="finish_date" value=<?php echo date("Y-m-d")?>>
        	<button class="btn btn-secondary" onclick="combochart_send()">GO!</button>
        	</div>
        	</div>
     	   </div>
		</div>
		<div class="row">
        	<div class="col">
        		<div id="combochart" style="width: 100%; height: 500px;"></div>
        	</div>
        </div>
        <div class="row" id="test">
        </div>
        </div>
	<?php     include '../top/manager_nav.php';?>
	    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>