<?php
$product_name = $_GET['product_name'];
echo $product_name;
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql="delete from product_list_tb where product_name='$product_name'";
mysqli_query($con, $sql);
$sql="delete from product_page_tb where product_name='$product_name'";
mysqli_query($con, $sql);

?>