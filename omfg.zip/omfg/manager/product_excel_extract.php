<?php
header( "Content-type: application/vnd.ms-excel" );
header( "Content-type: application/vnd.ms-excel; charset=utf-8");
header( "Content-Disposition: attachment; filename = product_list.xls" );
header( "Content-Description: PHP4 Generated Data" );
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql = "select * from product_list_tb order by registday desc";
$result = mysqli_query($con, $sql);

// 테이블 상단 만들기
$EXCEL_STR = "
<table border='1'>
<tr>
   <td>번호</td>
   <td>코드</td>
   <td>제품명</td>
   <td>제품유형</td>
   <td>가격</td>
   <td>포인트</td>
   <td>사이즈명</td>
   <td>상세사이즈1</td>
   <td>상세사이즈2</td>
   <td>상세사이즈3</td>
   <td>상세사이즈4</td>
   <td>상세사이즈5</td>
   <td>색상</td>
   <td>재고</td>
   <td>입고량</td>
   <td>출고량</td>
   <td>등록날짜</td>
</tr>";

while($row = mysqli_fetch_array($result)) {
    $EXCEL_STR .= "
   <tr>
       <td>".$row['product_num']."</td>
       <td>".$row['product_code']."</td>
       <td>".$row['product_name']."</td>
       <td>".$row['product_type']."</td>
       <td>".$row['price']."</td>
       <td>".$row['point']."</td>
       <td>".$row['size_name']."</td>
       <td>".$row['size1']."</td>
       <td>".$row['size2']."</td>
       <td>".$row['size3']."</td>
       <td>".$row['size4']."</td>
       <td>".$row['size5']."</td>
       <td>".$row['color']."</td>
       <td>".$row['inventory']."</td>
       <td>".$row['inventory_in']."</td>
       <td>".$row['inventory_out']."</td>
       <td>".$row['registday']."</td>
   </tr>
   ";
}

$EXCEL_STR .= "</table>";

echo "<meta content=\"application/vnd.ms-excel; charset=UTF-8\" name=\"Content-type\"> ";
echo $EXCEL_STR;


?>