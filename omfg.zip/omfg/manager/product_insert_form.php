<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <style type="text/css">
        h1{
            color: black;
        }
        
        .header{
            margin-bottom: 2rem;
        }
        .container#body{
            position: relative;
            top: 7rem;
            width: 50rem;
        }
        #btnSub{
            margin-left: 20rem;
            margin-bottom: 5rem;
        }
        .form-control-label{
            font-weight: bold;
        }
      
     </style>
     <script type="text/javascript">
      					function sizeCheck(){
          					var type = document.getElementById("product-type").value;
          					if(type=="b"){
          						document.getElementById("size1").disabled = false;
          						document.getElementById("size2").disabled = false;
          						document.getElementById("size3").disabled = false;
          						document.getElementById("size4").disabled = false;
          						document.getElementById("size5").disabled = false;
          						document.getElementById("size1").placeholder = "허리";
          						document.getElementById("size2").placeholder = "허벅지";
          						document.getElementById("size3").placeholder = "밑위";
          						document.getElementById("size4").placeholder = "밑단";
          						document.getElementById("size5").placeholder = "총장";
          					}else if(type=="s"||type=="a"){
          						document.getElementById("size1").disabled = false;
          						document.getElementById("size1").placeholder = "사이즈";
          						document.getElementById("size2").disabled = true;
          						document.getElementById("size3").disabled = true;
          						document.getElementById("size4").disabled = true;
          						document.getElementById("size5").disabled = true;
          						document.getElementById("size2").placeholder = "";
          						document.getElementById("size3").placeholder = "";
          						document.getElementById("size4").placeholder = "";
          						document.getElementById("size5").placeholder = "";
          					}else{
          						document.getElementById("size1").disabled = false;
          						document.getElementById("size2").disabled = false;
          						document.getElementById("size3").disabled = false;
          						document.getElementById("size4").disabled = false;
          						document.getElementById("size1").placeholder = "어깨";
          						document.getElementById("size2").placeholder = "가슴";
          						document.getElementById("size3").placeholder = "팔";
          						document.getElementById("size4").placeholder = "총장";
          						document.getElementById("size5").disabled = true;
          						document.getElementById("size5").placeholder = "";
          					}
      					}
      					
                    	
                    	
      				</script> 
  </head>
  <body>
  
 	<?php include '../top/top.php';
    if(!isset($_SESSION['userid'])||!$_SESSION['userid']=="admin"){
        echo "<script>alert('관리자 아이디로 로그인 해주시기 바랍니다.'); history.back();</script>";
    }
    ?>
	<div class="container" id="body">
        <div class="header">
          <div class="container">
            <h2 >제품 업데이트</h2>
          </div>
        </div>
    
    	<form action="./product_db_insert.php" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label class="form-control-label" for="product-name">제품명</label>
            <input type="text" class="form-control" id="product-name" name="product-name" placeholder="제품명" required>
          </div>
            <div class="form-group">
                <label class="form-control-label" for="product-type">제품유형</label>
                <select class="form-control" id="product-type" name="product-type" onchange="sizeCheck()" required>
                  <option value="o">OUTER</option>
                  <option value="t">TOP</option>
                  <option value="b">BOTTOM</option>
                  <option value="s">SHOES/BAG</option>
                  <option value="a">ACC</option>
                </select>
  			</div>
  		  <div class="form-row">
          <div class="form-group col-md-6">
            <label class="form-control-label" for="price">가격</label>
            <input type="text" class="form-control" id="price" name="price" placeholder="가격" required>
          </div>
          <div class="form-group col-md-6">
            <label class="form-control-label" for="point">적립금</label>
            <input type="text" class="form-control" id="point" name="point" placeholder="적립금" required>
          </div>
          </div>
          
          
          <div class="form-group" id="color-form">
            <label class="form-control-label" for="color">색상</label>
                <div class="input-group" >
      				<input type="text" id="color" class="form-control" placeholder="색상">
      				<span class="input-group-btn">
        		<button class="btn btn-secondary" type="button" onclick="plus()">+</button>
        		<script>
        			var count1=0;
        			function plus(){
        				count1++;
        				alert(count1);
        				var x= document.getElementById("color").value;
        				if(count1>1){
        					var id = "color-feild"+(count1-1);
        					var button = document.getElementById("button-span");
        					document.getElementById(id).removeChild(button);
        				}
        				document.getElementById("color-form").innerHTML+=("<div class='input-group' id='color-feild"+count1+"'><input class='form-control' type='text' name='color"+count1+"' placeholder='"+x+"' value='"+x+"' readonly><span class='input-group-btn' id='button-span'><button class='btn btn-secondary' type='button' id='"+count1+"' onclick='minus()'>-</button></span></div>");
	        			document.getElementById("color").value="";
            			document.getElementById("color-count").innerHTML = "<input type='hidden' name='color-count' value='"+count1+"'>";
        			}
        			function minus(){
        				var button = document.getElementById("button-span");
        				document.getElementById("color-form").removeChild(document.getElementById("color-feild"+count1)) 
        				count1--;
        				if(count1>=1){
        					document.getElementById("color-feild"+count1).appendChild(button);
        				}
        			}
        		</script>
        		
      		</span>
    		</div>
          </div>
          
          <div id="color-count">
          </div>
          
          <div class="form-group" id="size-form">
            <label class="form-control-label" for="size-name">사이즈</label>
                <div class="input-group" >
      				<select class="form-control" id="size-name">
                      <option>F</option>
                      <option>XS</option>
                      <option>S</option>
                      <option>M</option>
                      <option>L</option>
                      <option>XL</option>
                    </select>
      				<input class="form-control" type="text" id="size1" placeholder="어깨">
      				<input type="text" id="size2" class="form-control" placeholder="가슴">
      				<input type="text" id="size3" class="form-control" placeholder="팔">
      				<input type="text" id="size4" class="form-control" placeholder="총장">
      				<input type="text" id="size5" class="form-control" disabled>
      				<span class="input-group-btn">
        		<button class="btn btn-secondary" type="button" onclick="plus2()">+</button>
        		<script>
        			var count2=0;
        			function plus2(){
        				count2++;
        				var x= document.getElementById("size-name").value;
        				var x1= document.getElementById("size1").value;
        				var x2= document.getElementById("size2").value;
        				var x3= document.getElementById("size3").value;
        				var x4= document.getElementById("size4").value;
        				var x5= document.getElementById("size5").value;
        				if(x==""){
        					x=0;
        				}
        				if(x1==""){
        					x1=0;
        				}
        				if(x2==""){
        					x2=0;
        				}
        				if(x3==""){
        					x3=0;
        				}
        				if(x4==""){
        					x4=0;
        				}
        				if(x5==""){
        					x5=0;
        				}
        				document.getElementById("size-form").innerHTML+=(
        					"<div class='input-group'><input class='form-control' type='text' name='size"+count2+"' value='"+x+"-"+x1+"-"+x2+"-"+x3+"-"+x4+"-"+x5+"'>"
        					+"<span class='input-group-btn'><button class='btn btn-secondary' type='button' onclick='#'>+</button></div></span>");
            			document.getElementById("size-name").value="";
            			document.getElementById("size1").value="";
            			document.getElementById("size2").value="";
            			document.getElementById("size3").value="";
            			document.getElementById("size4").value="";
            			document.getElementById("size5").value="";
            			document.getElementById("size-count").innerHTML = "<input type='hidden' name='size-count' value='"+count2+"'>";
            			
        			}
        			
        		</script>
        		
      		</span>
    		</div>
          </div>
          
          <div id="size-count">
          </div>
          
          
          <div class="form-group">
            <label class="form-control-label" for="info">INFO</label>
            <textarea class="form-control" id="info" name="info" rows="5"></textarea>
          </div>
          
          <div class="form-row">
          <div class="form-group col-md-6">
            <label class="form-control-label" for="fabric">FABRIC</label>
            <input type="text" class="form-control" name="fabric" id="fabric" placeholder="FABRIC">
          </div>
          <div class="form-group col-md-6">
            <label class="form-control-label" for="model">MODEL</label>
            <input type="text" class="form-control" id="model" name="model" placeholder="MODEL">
          </div>
          </div>
          
          <div class="form-group">
            <label class="form-control-label" for="picture-front">대표사진</label>
            <input type="file" class="form-control" name="fpicture" id="picture-front">
          </div>
          
          <div class="form-group" id="pictures">
            <label class="form-control-label" for="picture-detail1">상세사진</label>
            <div class = "input-group">
                <span class="input-group-addon">1 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail1" disabled>
                <span class="input-group-btn" id="picture-button1">
                <button class="btn btn-secondary" type="button" onclick="pictureplus1()">+</button>
                <script>
                	function pictureplus1(){
                		document.getElementById("picture-detail1").disabled=false;
                		document.getElementById("picture-button1").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus1()'>-</button>"
                	}
                	function pictureminus1(){
                		document.getElementById("picture-detail1").disabled=true
                		document.getElementById("picture-button1").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus1()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">2</span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail2" disabled>
                <span class="input-group-btn" id="picture-button2">
                <button class="btn btn-secondary" type="button" onclick="pictureplus2()">+</button>
                <script>
                	function pictureplus2(){
                		document.getElementById("picture-detail2").disabled=false;
                		document.getElementById("picture-button2").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus2()'>-</button>"
                	}
                	function pictureminus2(){
                		document.getElementById("picture-detail2").disabled=true
                		document.getElementById("picture-button2").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus2()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">3</span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail3" disabled>
                <span class="input-group-btn" id="picture-button3">
                <button class="btn btn-secondary" type="button" onclick="pictureplus3()">+</button>
                <script>
                	function pictureplus3(){
                		document.getElementById("picture-detail3").disabled=false;
                		document.getElementById("picture-button3").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus3()'>-</button>"
                	}
                	function pictureminus3(){
                		document.getElementById("picture-detail3").disabled=true
                		document.getElementById("picture-button3").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus3()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">4 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail4" disabled>
                <span class="input-group-btn" id="picture-button4">
                <button class="btn btn-secondary" type="button" onclick="pictureplus4()">+</button>
                <script>
                	function pictureplus4(){
                		document.getElementById("picture-detail4").disabled=false;
                		document.getElementById("picture-button4").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus4()'>-</button>"
                	}
                	function pictureminus4(){
                		document.getElementById("picture-detail4").disabled=true
                		document.getElementById("picture-button4").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus4()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">5 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail5" disabled>
                <span class="input-group-btn" id="picture-button5">
                <button class="btn btn-secondary" type="button" onclick="pictureplus5()">+</button>
                <script>
                	function pictureplus5(){
                		document.getElementById("picture-detail5").disabled=false;
                		document.getElementById("picture-button5").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus5()'>-</button>"
                	}
                	function pictureminus5(){
                		document.getElementById("picture-detail5").disabled=true
                		document.getElementById("picture-button5").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus5()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">6 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail6" disabled>
                <span class="input-group-btn" id="picture-button6">
                <button class="btn btn-secondary" type="button" onclick="pictureplus6()">+</button>
                <script>
                	function pictureplus6(){
                		document.getElementById("picture-detail6").disabled=false;
                		document.getElementById("picture-button6").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus6()'>-</button>"
                	}
                	function pictureminus6(){
                		document.getElementById("picture-detail6").disabled=true
                		document.getElementById("picture-button6").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus6()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">7 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail7" disabled>
                <span class="input-group-btn" id="picture-button7">
                <button class="btn btn-secondary" type="button" onclick="pictureplus7()">+</button>
                <script>
                	function pictureplus7(){
                		document.getElementById("picture-detail7").disabled=false;
                		document.getElementById("picture-button7").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus7()'>-</button>"
                	}
                	function pictureminus7(){
                		document.getElementById("picture-detail7").disabled=true
                		document.getElementById("picture-button7").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus7()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">8 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail8" disabled>
                <span class="input-group-btn" id="picture-button8">
                <button class="btn btn-secondary" type="button" onclick="pictureplus8()">+</button>
                <script>
                	function pictureplus8(){
                		document.getElementById("picture-detail8").disabled=false;
                		document.getElementById("picture-button8").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus8()'>-</button>"
                	}
                	function pictureminus8(){
                		document.getElementById("picture-detail8").disabled=true
                		document.getElementById("picture-button8").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus8()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">9 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail9" disabled>
                <span class="input-group-btn" id="picture-button9">
                <button class="btn btn-secondary" type="button" onclick="pictureplus9()">+</button>
                <script>
                	function pictureplus9(){
                		document.getElementById("picture-detail9").disabled=false;
                		document.getElementById("picture-button9").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus9()'>-</button>"
                	}
                	function pictureminus9(){
                		document.getElementById("picture-detail9").disabled=true
                		document.getElementById("picture-button9").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus9()'>+</button>"
                	}
                </script>
                </span>
            </div>
            <div class = "input-group">
                <span class="input-group-addon">10 </span>
                <input type="file" class="form-control" name="dpicture[]" id="picture-detail10" disabled>
                <span class="input-group-btn" id="picture-button10">
                <button class="btn btn-secondary" type="button" onclick="pictureplus10()">+</button>
                <script>
                	function pictureplus10(){
                		document.getElementById("picture-detail10").disabled=false;
                		document.getElementById("picture-button10").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureminus10()'>-</button>"
                	}
                	function pictureminus10(){
                		document.getElementById("picture-detail10").disabled=true
                		document.getElementById("picture-button10").innerHTML = " <button class='btn btn-secondary' type='button' onclick='pictureplus10()'>+</button>"
                	}
                </script>
                </span>
            </div>

          </div>
          
          <button type="submit" class="btn btn-outline-dark" id="btnSub">확인</button>
		</form>
		
    </div>
    <?php include '../top/manager_nav.php';?>
    
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>