<?php
    $order_num = $_GET['order_num'];
    $changed_state = $_GET['changed_state'];
    $con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
    $sql="update order_list_tb set state='$changed_state' where order_num='$order_num'";
    mysqli_query($con, $sql) or mysqli_error($con);
    echo "$changed_state";
?>