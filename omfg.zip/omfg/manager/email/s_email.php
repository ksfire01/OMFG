 <?php 
 
 $t_content = $_POST['t_content'];
/* + $to : 받는사람 메일주소 ( ex. $to="hong <hgd@example.com>" 으로도 가능) +
 * $from : 보내는사람 이름 +
 *  $subject : 메일 제목 +
 *  $body : 메일 내용 +
 *  $cc_mail : Cc 메일 있을경우 (옵션값으로 생략가능) +
 *  $bcc_mail : Bcc 메일이 있을경우 (옵션값으로 생략가능) */


 include './s_mail.php';
$count=1;

$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql="select email from member_table";
$result=mysqli_query($con, $sql);
$to="";
while($row=mysqli_fetch_array($result)){
    $to.=$row['email'].",";
}
/* saruca@naver.com */
$from="관리자";
$subject="omfg에서 보낸 메일입니다.";
$body="$t_content";
$cc_mail="";
$bcc_mail=""; /* 메일 보내기*/
$sendmail->sendmail($to, $from, $subject, $body, $cc_mail,$bcc_mail);

?>