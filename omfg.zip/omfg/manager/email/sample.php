<?php 
include '../../top/top.php';
include '../../top/manager_nav.php';
?>
<html>
<head>
<meta charset="utf-8">
<style type="text/css">
    .container#body{
        width: 50rem;
        position: relative;
        top: 12rem;
    }
</style>
<script>
 function input(){
	 if(!document.sample_form.t_content.value){
		 alert("내용을 입력해주세요");
		 return;
	 }	 
	 document.sample_form.submit();
 }  
</script>
</head>
<body>
<div class="container" id="body">
<div class="header">
          <div class="container">
            <h2>메일전송</h2>
          </div>
        </div>
	<form name="sample_form" method="post" action="s_email.php">
		<div id="main">
			<!-- end of name -->
			<div id="content">
				<div id="col4">
					<textarea rows="13" cols="100" id="t_content" name="t_content"></textarea>
				</div>
			</div>
			<!-- end of content -->
			<input type="button" value="확인" onclick="input();">
			<!-- 확인버튼 -->
			<a href="../../newfile.php"><input type="button" value="취소"></a>
			<!-- 취소버튼 -->
		</div>
		<!-- end of main -->
	</form>
	<!-- end of form -->
	</div>
</body>
</html>
