<?php
header("Content-Type: application/json; charset=UTF-8");
$obj = json_decode($_GET['incoming'], false);
$con = new mysqli("localhost", "root", "123456", "shopdb");
$period = $obj->period;
if($period=="per_month"){
    $result = $con->query("select month(order_list_tb.date_col) as sales_period,
sum(buytbl.buy_price) as sales_total,
sum(if(product_list_tb.product_type='o', buytbl.buy_price, 0)) as sales_outer,
sum(if(product_list_tb.product_type='t', buytbl.buy_price, 0)) as sales_top,
sum(if(product_list_tb.product_type='b', buytbl.buy_price, 0)) as sales_bottom,
sum(if(product_list_tb.product_type='s', buytbl.buy_price, 0)) as sales_shoes,
sum(if(product_list_tb.product_type='a', buytbl.buy_price, 0)) as sales_acc    
from ((buytbl inner join order_list_tb on buytbl.order_num = order_list_tb.order_num) 
inner join product_list_tb on buytbl.product_code = product_list_tb.product_code)
where order_list_tb.date_col>='$obj->start_date' and order_list_tb.date_col<='$obj->finish_date'
group by month(order_list_tb.date_col)");
}else if($period=="per_week"){
    $result = $con->query("select week(order_list_tb.date_col) as sales_period,
sum(buytbl.buy_price) as sales_total,
sum(if(product_list_tb.product_type='o', buytbl.buy_price, 0)) as sales_outer,
sum(if(product_list_tb.product_type='t', buytbl.buy_price, 0)) as sales_top,
sum(if(product_list_tb.product_type='b', buytbl.buy_price, 0)) as sales_bottom,
sum(if(product_list_tb.product_type='s', buytbl.buy_price, 0)) as sales_shoes,
sum(if(product_list_tb.product_type='a', buytbl.buy_price, 0)) as sales_acc
from ((buytbl inner join order_list_tb on buytbl.order_num = order_list_tb.order_num)
inner join product_list_tb on buytbl.product_code = product_list_tb.product_code)
where order_list_tb.date_col>='$obj->start_date' and order_list_tb.date_col<='$obj->finish_date'
group by week(order_list_tb.date_col)");;
    
}else{
    $result = $con->query("select order_list_tb.date_col as sales_period,
sum(buytbl.buy_price) as sales_total,
sum(if(product_list_tb.product_type='o', buytbl.buy_price, 0)) as sales_outer,
sum(if(product_list_tb.product_type='t', buytbl.buy_price, 0)) as sales_top,
sum(if(product_list_tb.product_type='b', buytbl.buy_price, 0)) as sales_bottom,
sum(if(product_list_tb.product_type='s', buytbl.buy_price, 0)) as sales_shoes,
sum(if(product_list_tb.product_type='a', buytbl.buy_price, 0)) as sales_acc
from ((buytbl inner join order_list_tb on buytbl.order_num = order_list_tb.order_num)
inner join product_list_tb on buytbl.product_code = product_list_tb.product_code)
where order_list_tb.date_col>='$obj->start_date' and order_list_tb.date_col<='$obj->finish_date'
group by order_list_tb.date_col");;
}
$output = array();
$output = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($output);
?>