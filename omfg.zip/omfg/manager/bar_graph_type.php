<?php
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$product_type=$_GET['product_type'];

if($product_type=='x'){
    $sql="select product_name , sum(inventory_out), sum(inventory_out*price) from product_list_tb group by product_name";
    $res=mysqli_query($con, $sql);
}else{
$sql="select product_name , sum(inventory_out), sum(inventory_out*price) from product_list_tb where product_type='$product_type' group by product_name";
$res=mysqli_query($con, $sql);
}
$count1=0;
while ($row2=mysqli_fetch_array($res)){
    
        	echo "<input type='hidden' id= 'bar_product_name".$count1."' value=".$row2['product_name'].">";
        	echo "<input type='hidden' id= 'bar_inventory_out".$count1."' value=".$row2['sum(inventory_out)'].">";
        	echo "<input type='hidden' id= 'bar_money".$count1."' value=".$row2['sum(inventory_out*price)'].">";
        
            $count1++;
        }
       
			 echo "<input type='hidden' id='count1' value=$count1>";
			 
			 ?>