<?php
    $con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
    $product_name = $_POST['product-name'];
    $product_type = $_POST['product-type'];
    $price = $_POST['price'];
    $point = $_POST['point'];
    $color_count = $_POST['color-count'];
    $colors="";
     for($i=0;$i<$color_count;$i++){
         $color[$i] = $_POST['color'.($i+1)];
         echo $color[$i]."<br>";
         $colors.="$color[$i],";
     }
    
     $sizes="";
     $size_count = $_POST['size-count'];
     for($i=0;$i<$size_count;$i++){
         $size[$i] = $_POST['size'.($i+1)];
         $size_name[$i] = explode("-", $size[$i])[0];
         $size_detail1[$i] = explode("-", $size[$i])[1];
         $size_detail2[$i] = explode("-", $size[$i])[2];
         $size_detail3[$i] = explode("-", $size[$i])[3];
         $size_detail4[$i] = explode("-", $size[$i])[4];
         $size_detail5[$i] = explode("-", $size[$i])[5];
         echo $size_name[$i]."<br>";
         $sizes.="$size[$i],";
     }
     
     for($i=0;$i<$color_count;$i++){
         for($j=0;$j<$size_count;$j++){
             $product_code[$i][$j] = $product_name."-".$product_type."-".$color[$i]."-".$size_name[$j];
             echo "product_code[$i][$j]=".$product_code[$i][$j]."<br>";
         }
     }
     $info = $_POST['info'];
     $fabric = $_POST['fabric'];
     $model = $_POST['model'];
     
     
     
     
     $regist_day = date("Y-m-d");  // 현재의 '년-월-일-시-분'을 저장
     
     $sql = "select count(*) from product_page_tb where registday='$regist_day'";
     $res = mysqli_fetch_array(mysqli_query($con, $sql));
     $picture_count = $res['count(*)']+1;
     
     
     
     $fpicture_name	 = $_FILES["fpicture"]["name"];
     $fpicture_tmp_name = $_FILES["fpicture"]["tmp_name"];
     $fpicture_type     = $_FILES["fpicture"]["type"];
     $fpicture_size     = $_FILES["fpicture"]["size"];
     $fpicture_error    = $_FILES["fpicture"]["error"];
     
   
     $file = explode(".", $fpicture_name);
     $file_name = $file[0];
     $file_ext  = $file[1];
     
     $upload_dir = "../picture/";
     if (!$fpicture_error)
     {
         $new_file_name = date("ymd")."_".$picture_count."_f";
         $fpicture_copied = $new_file_name.".".$file_ext;
         $uploaded_fpicture = $upload_dir.$fpicture_copied;
         echo "uploaded_fpicture:".$uploaded_fpicture;
         
         
//          if ( ($fpicture_type != "image/gif") &&
//              ($fpicture_type != "image/jpeg") &&
//              ($fpicture_type != "image/pjpeg")&& 
//              ($fpicture_type != "image/png")&&
//              ($fpicture_type != "image/jpg"))
//          {
//              echo("
// 					<script>
// 						alert('JPG와 GIF 이미지 파일만 업로드 가능합니다!');
// 						history.go(-1)
// 					</script>
// 					");
//              exit;
//          }
         
         if (!move_uploaded_file($fpicture_tmp_name, $uploaded_fpicture) )
         {
             echo("
					<script>
					alert('파일을 지정한 디렉토리에 복사하는데 실패했습니다.');
					
					</script>
				");
             exit;
         }
     }
     
     
     $files = $_FILES["dpicture"];
     $count = count($files["name"]);
     echo $count;
     $upload_dir = '../picture/';
     for ($i=0; $i<$count; $i++)
     {
         
         $dpicture_name[$i]     = $files["name"][$i];
         $dpicture_tmp_name[$i] = $files["tmp_name"][$i];
         $dpicture_type[$i]     = $files["type"][$i];
         $dpicture_size[$i]     = $files["size"][$i];
         $dpicture_error[$i]    = $files["error"][$i];
         
         
         $file = explode(".", $dpicture_name[$i]);
         $file_name = $file[0];
         $file_ext  = $file[1];

         
         if (!isset($upfile_error[$i]))
         {
             $new_file_name = date("ymd").$picture_count."_d".$i;
             $dpicture_copied[$i] = $new_file_name.".".$file_ext;
             $uploaded_dpicture[$i] = $upload_dir.$dpicture_copied[$i];
             echo $uploaded_dpicture[$i]."<br>";
             
             
             if (!move_uploaded_file($dpicture_tmp_name[$i], $uploaded_dpicture[$i]) )
             {
                 echo("
					<script>
					alert('dpicture$i 파일을 지정한 디렉토리에 복사하는데 실패했습니다.');
				
					</script>
				");
                 exit;
             }
         }
     }
     for($i=$count; $i<10; $i++){
         $dpicture_copied[$i]="";
     }
     $sql="insert into product_page_tb(product_name, product_type, price, point, colors, sizes, info,";
     $sql.="fabric, model, fpicture, dpicture1, dpicture2, dpicture3, dpicture4, dpicture5, dpicture6,";
     $sql.="dpicture7, dpicture8, dpicture9, dpicture10, registday) ";
     $sql.="values('$product_name', '$product_type', $price, $point, '$colors', '$sizes', '$info',";
     $sql.="'$fabric', '$model', '$fpicture_copied', '$dpicture_copied[0]', '$dpicture_copied[1]', '$dpicture_copied[2]', '$dpicture_copied[3]', '$dpicture_copied[4]', '$dpicture_copied[5]', '$dpicture_copied[6]',";
     $sql.="'$dpicture_copied[7]', '$dpicture_copied[8]', '$dpicture_copied[9]', '$regist_day')";
     mysqli_query($con, $sql);
     
     for($i=0;$i<$color_count;$i++){
         for($j=0;$j<$size_count;$j++){
             $sql = "insert into product_list_tb(product_code, product_name, product_type, price, point,";
             $sql .="fpicture, size_name, size1, size2, size3, size4, size5, color, inventory, inventory_in, inventory_out, registday) ";
             $sql .="values('".$product_code[$i][$j]."', '$product_name', '$product_type', $price, $point, ";
             $sql .="'$fpicture_copied', '$size_name[$j]', $size_detail1[$j], $size_detail2[$j], $size_detail3[$j], ";
             $sql .="$size_detail4[$j], $size_detail5[$j], '$color[$i]', 0, 0, 0, '$regist_day')";
             mysqli_query($con, $sql) or die(mysqli_error($con));
         }
     }
     mysqli_close($con);
     
     
     
     
?>
<script>
	alert("제품등록이 완료되었습니다.");
	location.href="./product_manage.php";
</script>