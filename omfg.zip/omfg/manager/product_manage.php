<?php
    session_start();
    $con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
    $mode=isset($_GET['mode'])?$_GET['mode']:"";
    $page=isset($_GET['page'])?$_GET['page']:1;
    $block=isset($_GET['block'])?$_GET['block']:1;
    if($mode=="search"){
        if($_GET['search-type']=="product_name"){
            $sql="select * from product_page_tb where product_name like '%".$_GET['search-text']."%' order by date_col desc";
            $product_page_result=mysqli_query($con, $sql) or die(mysqli_error($con));
            
        }else if($_GET['search-type']=="product_type"){
            $sql="select * from product_page_tb where product_type='".$_GET['search-text']."' order by date_col desc";
            $product_page_result=mysqli_query($con, $sql);
            
        }
    }else{
    $sql="select * from product_page_tb order by date_col desc";
    $product_page_result=mysqli_query($con, $sql);
    $sql="select * from product_list_tb";
    $product_list_result=mysqli_query($con, $sql);
    
    }
    $a=0;
    $j=0;
    if(!isset($_SESSION['userid'])||!$_SESSION['userid']=="admin"){
        echo "<script>alert('관리자 아이디로 로그인 해주시기 바랍니다.'); history.back();</script>";
    }
    
    
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <link href="./carousel.css" rel="stylesheet">
     <style type="text/css">
        .container#top-menu{
        }
        .navbar{
            position: absolute;
            min-height: 100px;
        }
        a.nav-link{
            color: black;
            font-size: small;   
        }
        a.nav-link:hover{
            color: gray;
        }
        a.navbar-brand{
            color: black;
        }
        #menu1{
            
            align-content: center;
            align-items: center;
            padding-top: 45px;
        }
        #menu2{
            
            align-content: center;
            align-items: center;
            padding-top: 45px;
        }
        #logo{
            padding-left: 15px;
            font-family: "Century Gothic";
            font-size: 4em;
            font-weight: bolder;
            font-style: italic;
            text-align: center;
            color: black;
            text-decoration: none;
        }
        h1{
            color: black;
        }
        
        .header{
            margin-bottom: 2rem;
        }
        .container#body{
            position: relative;
            top: 8rem;
            width: 100rem;
            margin-bottom: 20rem;
        }
        #btnSub{
            margin-left: 20rem;
            margin-bottom: 5rem;
        }
        .form-control-label{
            font-weight: bold;
        }
        div#bigcol{
            
            
            background-color: rgb(240, 240, 230);
            
            
        }
        div#smallcol1{
            background-color: rgb(60, 60, 60);
            text-align: center;
            color: white;
            border-color: white;
            border-width: 1px 1px 1px 1px;
            border-style: solid;
            
        }
        .row#bigrow{
            min-height: 8rem;
        }
        
        .row#row1{
            /* height: 21%; */
        }
        
        .row#content-row{
            
        }
        
        div#smallcol2{
            border-color: white;
            border-width: 1px 1px 1px 1px;
            border-style: solid;
        }
        
        #fpicture{
            width: 160px;
            height: 250px;
        }
        
        
        .input-group{
            
        }
        .card{
            margin-bottom: 2rem;
        }
     </style>
     <script>
     	function plus_inventory(i, j, a){
     		var inventory_plus = document.getElementById("inventory_plus"+i+"_"+j).value;
     		var xhttp = new XMLHttpRequest();
     		xhttp.onreadystatechange = function(){
     			if(this.readyState==4 && this.status == 200){
     				document.getElementById("size"+i+"_"+j).innerHTML = this.responseText;
     			}
     		};
     		
     		xhttp.open("GET", "inventory_update.php?i="+i+"&j="+j+"&product_code="+a+"&inventory_in="+inventory_plus, true);
     		xhttp.send();
     		
     	}
     </script>
  </head>
  <body>
  
   <?php include '../top/top.php';?> 
	<div class="container" id="body">
    	<div class="header">
              <div class="container">
              	<div class="row">
              	<div class="col-md-6">
                <h2 >제품관리</h2>
                </div>
                <div class="col-md-5">
                <form action="product_manage.php" method="get">
                  <div class="input-group">
                  	<input type="hidden" value="search" name="mode">
                    <select class="form-control" id="product-type" name="search-type" required>
                      <option value="product_name">제품명</option>
                      <option value="product_type">제품유형</option>
                    </select>
                    <input type="text" class="form-control" name="search-text" placeholder="Search">
                    <div class="input-group-btn">
                      <button class="btn btn-default" type="submit">
                        	검색
                      </button>
                    </div>
                  </div>
                  </form>
                </div>
                </div>
              </div>
        </div>
        
        <?php 
            $content_per_page=5;
            $total_rows=mysqli_num_rows($product_page_result);
            $start_index=($page-1)*5;
            $total_pages=ceil($total_rows/$content_per_page);
            if($page==$total_pages){
                $content_per_page=$total_rows-$start_index;
            }
            for($ty=$start_index;$ty<$start_index+$content_per_page;$ty++){
                mysqli_data_seek($product_page_result, $ty);
                $row=mysqli_fetch_array($product_page_result);
                $a++;
                
        ?>
        <div class = "card">
        <div class = "card-header">
        <div class="row">
        <div class="col-md-11">
        등록날짜 : <?=$row['registday'] ?>
        </div>
        <div class="col-md-1">
        <a href="product_delete.php?product_name=<?=$row['product_name']?>" class="btn btn-danger btn-md active" role="button" aria-pressed="true">삭제</a>
        </div>
        </div>
        </div>
        <div class = "card-body">
    	<div class="row" id="content-row">
    		<div class="col-md-3" id="bigcol">
    			<div class="row">
    				<div class="col-md-8" id="smallcol1">
    					대표사진
    				</div>
    				<div class="col-md-4" id="smallcol1">
    					제품명
    				</div>
    			</div>
    			<div class="row">
    				<div class="col-md-8" id="smallcol2">
    					<img src="../picture/<?=$row['fpicture'] ?>" id="fpicture">
    				</div>
    				<div class="col-md-4" id="smallcol2">
    					<?=$row['product_name'] ?>
    				</div>
    			</div>
    		</div>
    		
    		<div class="col-md-9" id="bigcol">
    			<div class="row" id="bigrow">
    				<div class="col-md-5">
    				<div class="row">
    				<div class="col-md-4">
            			<div class="row" >
            				<div class="col" id="smallcol1">
            					제품유형
            				</div>
            			</div>
            			<div class="row">
            				<div class="col" id="smallcol2">
            					<?=$row['product_type'] ?>
            				</div>
            			</div>    				
    				</div>
    				
    				<div class="col-md-4">
            			<div class="row" id="row2">
            				<div class="col" id="smallcol1">
            					가격
            				</div>
            			</div>
            			<div class="row" id="row1">
            				<div class="col" id="smallcol2">
            					<?=$row['price'] ?>
            				</div>
            			</div>
    				
    				</div>
    				
    				<div class="col-md-4">
        				<div class="row" id="row2">
            				<div class="col" id="smallcol1">
            					적립금
            				</div>
            			</div>
            			<div class="row" id="row1">
            				<div class="col" id="smallcol2">
            					<?=$row['point'] ?>
            				</div>    			            			
            			</div>    				
    				</div>
    				</div>
    				</div>
    				
    				<div class="col-md-7">
    					<div class="row">
    						<div class="col-md-8">
                    			<div class="row">
                    				<div class="col" id="smallcol1">
                    				사이즈		
                    				</div>
                    			</div>
                    			<?php
                    			$sizes=explode(",", $row['sizes']);
                    			 for($i=0;$i<count($sizes)-1;$i++){
                    			     $size_detail=explode("-", $sizes[$i])    
                    			 
                    			?>
                    			<div class="row" >
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[0] ?>
                    				</div>		
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[1] ?>
                    				</div>		
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[2] ?>
                    				</div>		
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[3] ?>
                    				</div>		
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[4] ?>
                    				</div>		
                    				<div class="col-md-2" id="smallcol2">
                    					<?=$size_detail[5] ?>
                    				</div>		
                    			</div>
                    			<?php 
                    			 
                    			 }
                    			?>

    						</div>
    						<div class="col-md-4">
                				<div class="row" >
                    				<div class="col" id="smallcol1">
                    				색상
                    				</div>		
                    			</div>
                    			<div class="row" >
                    				<div class="col" id="smallcol2">
                    					<?=$row['colors'] ?>
                    				</div>
                    			</div>                    			
    						</div>
    					</div>    				
    				</div>
    			</div>
    			<div class="row">
    				<div class="col">
    					<div class="row">
            				<div class="col-md-3" id="smallcol1">
            					색상-사이즈
            				</div>
            				<div class="col-md-2" id="smallcol1">
            					총입고수량
            				</div>
            				<div class="col-md-2" id="smallcol1">
            					총출고수량
            				</div>
            				<div class="col-md-2" id="smallcol1">
            					재고수량
            				</div>
            				<div class="col-md-3" id="smallcol1">
            					입고
            				</div>
    					</div>
    					
    					<div class="row">
    					<div class="col">
                			<?php 
                			     $sql="select product_code, size_name, color, inventory, inventory_in, inventory_out from product_list_tb where product_name='".$row['product_name']."'";
                			     $res2=mysqli_query($con, $sql);
                			     while($row2=mysqli_fetch_array($res2)){
                			         $j++;
                			?>
                			<div class="row" id="<?php echo 'size'.$a.'_'.$j ?>">
                				<div class="col-md-3" id="smallcol2">
                					<?=$row2['color']?>-<?=$row2['size_name']?>
                				</div>
                				<div class="col-md-2" id="smallcol2">
                					<?=$row2['inventory_in']?>
                				</div>
                				<div class="col-md-2" id="smallcol2">
                					<?=$row2['inventory_out'] ?>
                				</div>
                				<div class="col-md-2" id="smallcol2">
                					<?=$row2['inventory'] ?>
                				</div>
                				<div class="col-md-3" id="smallcol2">
                					<div class="input-group input-group-sm">
                						<input type="number" class="form-control" id="<?php echo "inventory_plus".$a."_".$j ?>">
                						<span class="input-group-btn">
                							<button class="btn btn-secondary" type="submit" onclick="plus_inventory(<?=$a?>, <?=$j?>, '<?=addslashes($row2['product_code'])?>')">확인</button>
                						</span>
                					</div>
                				</div>
                			</div>
                			<?php 
                			     }
                			?>
    					</div>
    					</div>
    				</div>
    			
    			</div>
    			
    			
    			
    		</div>
    		
    	</div>
    	</div>
    	</div>
    	<?php 
            }
    	?>
    	<nav aria-label="Page navigation example">
          <ul class="pagination justify-content-center">
          <?php 
                $pages_per_block=5;
                $total_blocks=ceil($total_pages/$pages_per_block);
                $start_page=($block-1)*$pages_per_block+1;
                if($block==$total_blocks){
                    $pages_per_block=$total_pages-$start_page;
                }
                if($block>1){
                    ?>
			<li class="page-item"><a class="page-link" href=<?php echo "/homepage/omfg/manager/product_manage.php?page=".($start_page-1)."&block=".($block-1)?>>Previous</a></li>
                    <?php
                }
                
                for($i=$start_page;$i<=$start_page+$pages_per_block;$i++){
                    echo "<li class='page-item'><a class='page-link' href='/homepage/omfg/manager/product_manage.php?page=$i&block=$block'>$i</a></li>";
                }
                
                if($block<$total_blocks){
                    echo "<li class='page-item'><a class='page-link' href='/homepage/omfg/manager/product_manage.php?page=".($start_page+$pages_per_block)."&block=".($block+1)."'>Next</a></li>";
                }
              
              ?>
           		
            
          </ul>
        </nav>
    	<a href="product_excel_extract.php" class="btn btn-primary btn-md active" role="button" aria-pressed="true">엑셀추출</a>
    </div>
    <?php include '../top/manager_nav.php';?>
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>