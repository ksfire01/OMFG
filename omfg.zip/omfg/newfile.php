<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="./bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <link href="carousel.css" rel="stylesheet">
     <style type="text/css">


        #logo{
            padding-left: 15px;
            font-family: "Century Gothic";
            font-size: 4em;
            font-weight: bolder;
            font-style: italic;
            text-align: center;
            color: black;
            text-decoration: none;
        }
        #logo:hover{
            
        }
        #new-arrival{
            position : relative;
            bottom : 7rem;
            font-family: "Century Gothic";
            font-size: 2em;
            text-align: center;
            text-decoration: underline;
        }
        .album {
          position : relative;
          bottom : 7rem;
          min-height: 50rem; /* Can be removed; just added for demo purposes */
          padding-bottom: 3rem;
          
        }
        
        .card {
          float: left;
          width: 33.333%;
          padding: .75rem;
          margin-bottom: 2rem;
          border-color: "white";
        }
        
        .card > img {
          margin-bottom: .75rem;
          height: 25rem;
          
        }
        
        .card-text {
          font-size: 100%;
          color: black;
          text-align: center;
        }
        .card:hover{
            text-decoration: none;
            background-color: rgb(245, 245, 245);
        }
        #manager_nav{
            
        }
      
     </style> 
  </head>
  <?php include './top/top.php'?>
  <body>
  

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="./img/main_1.jpg" alt="First slide" style="opacity: 0.6;">
      <div class="carousel-caption d-none d-md-block ">
    <h1><b style="color: white;">2017 F/W 아우터 특별전</b></h1>
    <p>신상품 20%할인 이벤트</p>
  	</div>
    </div>
    <div class="carousel-item">
 	 <img src="./img/main_2.jpg" alt="..." style="opacity: 0.6;">
  	<div class="carousel-caption d-flex justify-content-end">
    <h1><b style="color: white;">시즌아웃 상품 1+1 이벤트</b></h1>
  	</div>
	</div>
    <div class="carousel-item">
      <img src="./img/main_3.jpg" alt="Third slide" style="opacity: 0.6;">
      <div class="carousel-caption d-flex justify-content-start">
    <h1><b style="color: white;">OMFG PANTS</b></h1>
    <p style="position: relative; left: 2rem; top: 1rem;">고퀄리티 자체제작</p>
  	</div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<?php 
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
$sql="select * from product_page_tb order by num desc";
$res=mysqli_query($con, $sql);
?>
<div class="col-md-12">
	<p id="new-arrival">N E W &nbsp; A R R I V A L</p>
</div>
<div class="album">
<div class="container">
<div class="row">
<?php
$pointer=0;
for($i=0;$i<9;$i++){
    mysqli_data_seek($res, $i);
    $row = mysqli_fetch_array($res);
?>
	
		<a class="card" style="border-color: white;" href="./detail/detailpage.php?name=<?=$row['product_name']?>">
            <img src="./picture/<?=$row['fpicture']?>" alt="">
            <p class="card-text" id="product-name"><b><?=$row['product_name'] ?></b><br><?=$row['price'] ?> KRW</p>
          </a>
<?php 
    
?>
<?php
}
?>
</div>
</div>
</div>

<?php if(isset($_SESSION['userid'])&&$_SESSION['userid']=="admin") include './top/manager_nav.php';?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
  <footer class="text-muted">
	<img src="./img/footer.jpg" style="width: 100%; height: 30rem;">
  </footer>
</html>