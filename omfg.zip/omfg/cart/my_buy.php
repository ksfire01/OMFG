<?php
session_start();
include "./include/common.php";
include "./include/class.inc";
include "../top/top.php";
$con = mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
if(isset($_GET['mode'])){
    if(isset($_SESSION['userid'])){
        $userid=$_SESSION['userid'];
        
        $sql = "select product_list_tb.fpicture as fpicture, order_list_tb.date_col as order_day,  product_list_tb.product_name as product_name,
    buytbl.buy_quantity as buy_quantity, buytbl.buy_price as buy_price, product_list_tb.point as point,
    order_list_tb.state as state, order_list_tb.order_num as order_num, buytbl.size as size, buytbl.color as color
    from (buytbl join product_list_tb on buytbl.product_code = product_list_tb.product_code)
    join order_list_tb on buytbl.order_num = order_list_tb.order_num
    where buytbl.userid = '$userid' and order_list_tb.state = '주문접수중' and order_day>='".$_POST['start_date']."' and order_day<='".$_POST['finish_date']."'";
        
        $result = mysqli_query($con, $sql);
        $o_num = mysqli_num_rows($result);
        $row = mysqli_fetch_array($result);
        
        $sql = "select product_list_tb.fpicture as fpicture, order_list_tb.date_col as order_day,  product_list_tb.product_name as product_name,
    buytbl.buy_quantity as buy_quantity, buytbl.buy_price as buy_price, product_list_tb.point as point,
    order_list_tb.state as state, order_list_tb.order_num as order_num, buytbl.size as size, buytbl.color as color
    from (buytbl join product_list_tb on buytbl.product_code = product_list_tb.product_code)
    join order_list_tb on buytbl.order_num = order_list_tb.order_num
    where buytbl.userid = '$userid' and order_list_tb.state = '배송완료' and order_day>='".$_POST['start_date']."' and order_day<='".$_POST['finish_date']."'";
        
        $result2 = mysqli_query($con, $sql);
        $o_num2 = mysqli_num_rows($result2);
        $row2 = mysqli_fetch_array($result2);
    }else{
        echo "location.href='../login/login/login_form.php'";
    }
}else{
if(isset($_SESSION['userid'])){
    $userid=$_SESSION['userid'];
    
    $sql = "select product_list_tb.fpicture as fpicture, order_list_tb.order_day as order_day,  product_list_tb.product_name as product_name,
    buytbl.buy_quantity as buy_quantity, buytbl.buy_price as buy_price, product_list_tb.point as point,
    order_list_tb.state as state, order_list_tb.order_num as order_num, buytbl.size as size, buytbl.color as color
    from (buytbl join product_list_tb on buytbl.product_code = product_list_tb.product_code)
    join order_list_tb on buytbl.order_num = order_list_tb.order_num
    where buytbl.userid = '$userid' and order_list_tb.state = '주문접수중'";
    
    $result = mysqli_query($con, $sql);
    $o_num = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);
    
    $sql = "select product_list_tb.fpicture as fpicture, order_list_tb.order_day as order_day,  product_list_tb.product_name as product_name,
    buytbl.buy_quantity as buy_quantity, buytbl.buy_price as buy_price, product_list_tb.point as point,
    order_list_tb.state as state, order_list_tb.order_num as order_num, buytbl.size as size, buytbl.color as color
    from (buytbl join product_list_tb on buytbl.product_code = product_list_tb.product_code)
    join order_list_tb on buytbl.order_num = order_list_tb.order_num
    where buytbl.userid = '$userid' and order_list_tb.state = '배송완료'";
    
    $result2 = mysqli_query($con, $sql);
    $o_num2 = mysqli_num_rows($result2);
    $row2 = mysqli_fetch_array($result2);
}else{
    echo "location.href='../login/login/login_form.php'";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>주문</title>
<link href = "./include/order_history.css" rel="stylesheet" type="text/css" media="all">
<link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="//code.jquery.com/ui/1.8.18/jquery-ui.min.js"></script>
<style type="text/css">
.container#body{
            position: relative;
            top: 6rem;
            width:55rem;
        }
</style>
<script>
  $.datepicker.setDefaults({
    dateFormat: 'yy-mm-dd',
    prevText: '이전 달',
    nextText: '다음 달',
    monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    dayNames: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
    showMonthAfterYear: true,
    yearSuffix: '년'
  });

  $(function() {
    $("#datepicker1, #datepicker2").datepicker();
  });
	
</script>
<script>
   	var today = new Date ();
    function check_today(){
    	document.getElementById("datepicker1").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    	document.getElementById("datepicker2").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    }
    function check_week(){
    	document.getElementById("datepicker1").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+(today.getDate()-7);
    	document.getElementById("datepicker2").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    }
    function check_m_1(){
    	document.getElementById("datepicker1").value = today.getFullYear()+'-'+today.getMonth()+'-'+today.getDate();
    	document.getElementById("datepicker2").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    }
    function check_m_3(){
    	document.getElementById("datepicker1").value = today.getFullYear()+'-'+(today.getMonth()-2)+'-'+today.getDate();
    	document.getElementById("datepicker2").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    }
    function check_m_6(){
    	document.getElementById("datepicker1").value = today.getFullYear()+'-'+(today.getMonth()-5)+'-'+today.getDate();
    	document.getElementById("datepicker2").value = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    }
    

</script>
</head>
<body>
<div class="container" id="body">
<div id="wrap">
<div id="content">
<form name="cart" method="post" action="my_buy.php?mode='search'">
<div id="header" style="font-size : 20px">ORDER HISTORY</div>

<div id="daysearch">
<input type="button" id="tbtn" name="today" value="오늘" onclick="check_today();">
<input type="button" id="wbtn" name="week" value="1주일" onclick="check_week()">
<input type="button" id="m_1btn" name="m_1" value="1개월" onclick="check_m_1()">
<input type="button" id="m_3btn" name="m_3" value="3개월" onclick="check_m_3()">
<input type="button" id="m_6btn" name="m_6" value="6개월" onclick="check_m_6()">
&nbsp;&nbsp;&nbsp;&nbsp;조회기간:
	<input type="text" name="start_date" id="datepicker1" readonly> ~
	<input type="text" name="finish_date" id="datepicker2" readonly>
	<input type="submit" id="sdbtn" value="검색">
</div>

<?php 
    if(isset($_SESSION['userid'])){
        $userid = $_SESSION['userid'];

?>
    <div id="order">주문내역 조회 (<?=$o_num?>)</div>
    <div id="order_in">주문상품정보</div>
    <div id="date">주문일자<br>[주문번호]</div>
    <div id="picture">이미지</div>
    <div id="product_info">상품정보</div>
    <div id="quantity">수량</div>
    <div id="total_price">상품구매금액</div>
    <div id="delivery">배송</div>
    
<?php 
    /* where order_list_tb.date_col>='$obj->start_date' and order_list_tb.date_col<='$obj->finish_date' */

    $sum = 0;
    for ($i=0; $i<$o_num; $i++) {
        mysqli_data_seek($result, $i);
        $row = mysqli_fetch_array($result);
        
?>
    <div id="date_2"><?=$row['order_day']?><br>[<?=$row['order_num']?>]</div>
    <div id="picture_2"><img alt="" src="../picture/<?=$row['fpicture']?>" style="height: 100px; width: 120px;"></div>
    <div id="product_info_2">상품명 : <?=$row['product_name']?><br>
    						  사이즈 : <?=$row['size']?><br> 색상 : <?=$row['color']?></div>
    <div id="quantity_2"><?=$row['buy_quantity']?> 개</div>
    <div id="total_price_2"><?=$row['buy_price']?> 원</div>
    <div id="delivery_2"><?=$row['state']?></div>
    
<?php
    }
?>
	<div id="order_2">지난 주문 내역 (<?=$o_num2?>)</div>
    <div id="order_in_2">주문상품정보</div>
    <div id="date">주문일자<br>[주문번호]</div>
    <div id="picture">이미지</div>
    <div id="product_info">상품정보</div>
    <div id="quantity">수량</div>
    <div id="total_price">상품구매금액</div>
    <div id="delivery">배송</div>
<?PHP
$total_row = mysqli_num_rows($result2); // 검색된 총 개수
$PAGE_LINE = 5; // 페이지당 보여질 개수
$LINK_NUM = 2; // 현재 페이지를 기준으로 좌우로 몇개 보여줄지 결정
$total_page = (int) (($total_row - 1) / $PAGE_LINE) + 1; // 전체페이지수
$page_num = 0;                                                        

if ($total_row > 0) {
    if (($page_num == "") || ($page_num < 1) || ($page_num > $total_page))
        $page_num = 1;
    
    $go_page = ($page_num - 1) * $PAGE_LINE;
    
    $i = 0;
    mysqli_data_seek($result2, $go_page);
}

while ($row2 = mysqli_fetch_array($result2)) {
    if ($i >= $PAGE_LINE)
        break;
    $i ++;
    ?>
	<div id="date_2"><?=$row2['order_day']?><br>[<?=$row2['order_num']?>]</div>
    <div id="picture_2"><img alt="" src="../picture/<?=$row2['fpicture']?>" style="height: 100px; width: 120px;"></div>
    <div id="product_info_2">상품명 : <?=$row2['product_name']?><br>
    						  사이즈 : <?=$row2['size']?><br> 색상 : <?=$row2['color']?></div>
    <div id="quantity_2"><?=$row2['buy_quantity']?> 개</div>
    <div id="total_price_2"><?=$row2['buy_price']?> 원</div>
    <div id="delivery_2"><?=$row2['state']?></div>
<?PHP
}
?>
<div id="page_num">
<?PHP
if ($total_row > 0) {
    echo "<br><br><a href='./my_buy.php?page_num=1'><<</a>&nbsp;&nbsp;";
    $i = $page_num - $LINK_NUM;
    if ($i < 1) {
        $j = $page_num + $LINK_NUM - $i + 1;
        if ($j > $total_page)
            $j = $total_page;
        $i = 1;
    } else {
        $j = $page_num + $LINK_NUM;
        if ($j > $total_page) {
            $i = $i + $total_page - $j;
            if ($i < 1)
                $i = 1;
            $j = $total_page;
        }
    }
    
    for ($i = 1; $i <= $j; $i ++) {
        if ($i == $page_num)
            echo "<a href='./my_buy.php?page_num=$i'><b>$i</b></a>&nbsp;";
        else
            echo "<a href='./my_buy.php?page_num=$i'>$i</a>&nbsp;";
    }
    echo "&nbsp;<a href='./my_buy.php?page_num=$total_page'>>></a>";
}
?>
</div>
</form>

</div> <!-- content -->
</div> <!-- wrap -->
</div>
<?php 
    }else{
        echo "<div id='empty_mss'>주문내역이 없습니다.</div>";
    }
?>
<div id="footer">
	<a><img src="./image/footer.jpg"></a>
	</div>
</body>
</html>