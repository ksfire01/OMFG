<?php
include "./include/common.php";

$flag = "NO";

$sql = "SHOW TABLES FROM shopDB";
$result = mysqli_query($con, $sql);
if (! $result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: ' . mysqli_error();
    exit();
}

while ($row = mysqli_fetch_row($result)) {
    if ($row[0] == "order_list_tb") {
        $flag = "OK";
        break;
    }
}

/* 테이블이 존재하지 않으면 테이블생성 */
if ($flag != "OK") {
    $sql = "create table order_list_tb (
        order_num varchar(20) primary key not null,
        order_day varchar(20),
        total_price int,
        state varchar(10),
        userid varchar(20),
        receiver varchar(30),
        address varchar(255),
        message varchar(255),
        pay_method varchar(20),
        foreign key(userid) references member_table(userid))";
    
    $result = mysqli_query($con, $sql) or die("<font size=4><br><center>order_list_tb생성중 오류</font><hr>
    <script>
    alert('[buytbl 테이블생성중 오류] 테이블 생성중 오류; ');
    </script>");
    if (! $result) {
        echo "DB Error, MySQL Error: ".mysqli_error();
        exit();
    }
}
echo "<font size=4><br><center>order_list_tb 성공적으로 만듬</font><hr>
<script>
alert('[테이블생성성공] order_list_tb 테이블 생성');
location.replace('./newfile.php');
</script>";
mysqli_close($con); // db연결 종료
?>
