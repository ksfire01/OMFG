<?php 
    $con = mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
    $sql = "create table order_list_tb (
                num int primary key auto_incremnet,
                order_day varhcar(20),
                total_price int,
                delivery varchar(10),
                userid varchar(20),
                product1 varchar(30),
                product2 varchar(30),
                product3 varchar(30),
                product4 varchar(30),
                product5 varchar(30),
                product6 varchar(30),
                product7 varchar(30),
                product8 varchar(30),
                product9 varchar(30),
                product10 varchar(30),
                number1 int,
                number2 int,
                number3 int,
                number4 int,
                number5 int,
                number6 int,
                number7 int,
                number8 int,
                number9 int,
                number10 int);";
?>