<?PHP
include './include/common.php';
include "./include/class.inc";
include '../top/top.php';
session_start();
$con=mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
if(isset($_SESSION['userid'])){
    $userid=$_SESSION['userid'];
}
if (isset($_POST['id'])) {
    $id = $_POST['id'];
}
if (isset($_POST['size'])) {
    $size = $_POST['size'];
}
if (isset($_POST['color'])) {
    $color = $_POST['color'];
}
if (isset($_POST['buy_quantity'])) {
    $buy_quantity = $_POST['buy_quantity'];
}
if (isset($_POST['buy_price'])) {
    $buy_price = $_POST['buy_price'];
}
if (isset($_POST['point'])) {
    $point = $_POST['point'];
}
if (isset($_POST['product_name'])) {
    $product_name = $_POST['product_name'];
}
if (isset($_GET['code'])) {
    $code = $_GET['code'];
} else {
    $code ="";
}

/* echo "테스트 : $size, $color, $buy_quantity, $buy_price, $point, $product_name, $code"; */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = new Cart();
}

if ($code == "insert") {
    $sql = "select product_code, fpicture from product_list_tb where product_name='$product_name'
                  and size_name='$size' and color='$color'";
    $res = mysqli_query($con, $sql) or mysqli_error($con);
    $row = mysqli_fetch_array($res);
    $id = $row['product_code'];
    $fpicture = $row['fpicture'];
    
    $sql = "select fpicture from product_page_tb where product_name='$product_name'";
    $row = mysqli_fetch_array($res);
    $_SESSION['cart']->add($id, $product_name, $size, $color, $buy_quantity, $point, $buy_price, $fpicture);// 새로운 내용 장바구니 추가함
}
else if ($code == "delete") {
    $_SESSION['cart']->deletes($id);
}else if ($code == "unset"){
    $_SESSION['cart']->__unset($id);
}

if(isset($_SESSION['userid'])){
    $sql2 = "select * from member_table where userid='$userid'";
    $res = mysqli_query($con, $sql2);
    $row = mysqli_fetch_array($res);
    
    $point = $row['point'];
}
?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="./include/cart.css" />
 <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
.container#body{
            position: relative;
            top: 2rem;
            width: 62rem;
        }
</style>
<script>
    function CheckAll(){ 
	    var gChk = document.getElementsByName("check_group"); //체크박스의 name값
   		var nChk = document.getElementsByName("check_num[]");
    	if(gChk[0].checked){ 
    		for(i=0 ; i<nChk.length ; i++){ 
    			nChk[i].checked = true; //체크되어 있을경우 설정변경
    		}
    	}else{
    		for(i=0; i<nChk.length;i++){ 
    			nChk[i].checked = false; 
    		} 
    	}
    }
    function CheckGroup(form){
    	var i; 
    	var nChk = document.getElementsByName("check_num[]"); //체크되어있는 박스 value값
    		form['gid'].value ='';
    		if(nChk){
    			for(i=0 ; i<nChk.length ; i++) { 
    				if(nChk[i].checked){ //체크되어 있을경우 
    					if(form['gid'].value ==''){
    						form['gid'].value = nChk[i].value;
    				}else{
    					form['gid'].value = form['gid'].value+ ',' +nChk[i].value; //구분자로 +=
    				}
    			} 
    		}
    		if(form['gid'].value ==''){ //선택이 하나도 안되어있을 경우
    			alert("삭제할 품목을 선택해 주세요."); 
    				return false; 
    			}
    		return true;
    		}
    	}
</script>
</head>
<body>
<?php /*include '../top/top.php'*/?> 
<div class="container" id="body">
<form name="pr_list" method="post" action="cart.php" onsubmit="return CheckGroup(this)">
<?php 
if ($_SESSION['cart']->get_count()) {//새로운 카트 추가가 있을때 get_count로 카트 수 확인
    $contents = $_SESSION['cart']->get_list();//contents값을 불러옴

    ?>
    
	<div id="header">CART</div>
    <div id="benefit">혜택정보&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;가용 적립금 :<strong> <?=$point?>P</strong></div>
    <div id="delivery">배송상품</div>
    <div id="delivery_01">일반 상품</div>
    <div id="checkbox"><input type="checkbox" name="check_group" onclick="javascript:CheckAll()"></div>
    <div id="info_01">이미지</div>
    <div id="info_02">상품정보</div>
    <div id="info_03">판매가</div>
    <div id="info_04">수량</div>
    <div id="info_05">적립금</div>
    <div id="info_06">배송비</div>
    <div id="info_07">합계</div>
    <div id="info_08">선택</div>
	<?php 
    	$sum = 0;
    	
    	while (list ($id, $value) = each($contents)) {
    	    $sm_sum = $value[3] * $value[4]; // 합계 = 수량 * 가격
    	    $sum += $sm_sum; // 전체 합계
    ?>
	
	<div id="checkbox02"><input type="checkbox" name="check_num[]" value=<?php echo("$id")?>></div>
    <div id="info_11"><img alt="" src=<?php echo "../picture/$value[6]"?> style="height: 100px; width: 100px;"></div>
    <div id="info_12">품목명 : <?=$value[0]?><br>사이즈 : <?=$value[1]?><br>색상 : <?=$value[2]?></div>
    <div id="info_13"><?=$value[4]?> 원</div>
    <div id="info_14"><?=$value[3]?> 개</div>
    <div id="info_15"><?=$value[5]*$value[3]?> P</div>
    <div id="info_16">무료</div>
    <div id="info_17">총 : <?=$sm_sum?>원</div>
    <div id="info_18">
    <div id="buybtn"><input type="button" id="bbtn" value="주문하기"
     onclick="javascript:location='order.php'"></div>
    <div id="deletebtn"><input type="button" id="delbtn" value="삭제"
     onclick="javascript:location='cart.php?code=delete&id=<?=$id?>'"></div>
    </div>
    <div id="buy_product">&nbsp;&nbsp;</div>
	
<?php
    $t_id = $id;
    } /* end of while */
?>
 
	<div id="select_delete_id">&nbsp;&nbsp;선택 상품을 
	<input type="hidden" name="gid">
	<input type="button" id="sel_del_id" value="삭제하기"
	onclick="javascript:location='cart.php?code=delete&id=<?php echo $t_id?>'">

	</div>
	<div id="total_price">상품구매금액 : <?=$sum?>원 + 배송비(무료) = <?=$sum?>원</div>
	<div id="clearcart"><input type="button" id="clbtn"
	value="장바구니비우기" onclick="javascript:location='cart_delete.php'"></div>
	<div id="all">
	<div id="total_p"><strong>총 상품금액</strong></div>
	<div id="total_dp"><strong>총 배송비</strong></div>
	<div id="pay"><strong>결제예정금액</strong></div>
	
	<div id="total_p_2">KRW <b><?=$sum?></b></div>
	<div id="total_dp_2">+ KRW <b>0</b></div>
	<div id="pay_2">=KRW <b><?=$sum?></b></div>
	</div>
	
	<div id="continue">
	<input type="button" id="conbtn" value="쇼핑계속하기" 
	onclick="javascript:location='../newfile.php'">
	<input type="button" id="allbuy" value="전체상품주문"
	onclick="javascript:location='order.php'">
	<input type="button" id="selectbuy" value="선택상품주문"
	onclick="javascript:location='order.php'">
	</div>
	</form>
<?php 
} else { //새로운 카트가 없으면 echo 출력
    echo ("<br><br><p align=center><font id='aa'>장바구니가 비었습니다.</font></p>");
    unset($_SESSION['cart']); // 세션해제
?>

<div id="lbtn">
	<input type="button" id="con_btn" value="쇼핑하러가기" 
		onclick="javascript:location='../newfile.php'">
</div>

<?php 
    }
?>
	<div id="guide">이용안내</div>
	<div id="cart_guide"><br>
	&nbsp; 장바구니 이용안내 <br><br>
		&nbsp;&nbsp;① 해외배송 상품과 국내배송 상품은 함께 결제하실 수 없으니 장바구니 별로 따로 결제해 주시기 바랍니다.<br>
		&nbsp;&nbsp;② 해외배송 가능 상품의 경우 국내배송 장바구니에 담았다가 해외배송 장바구니로 이동하여 결제하실 수 있습니다.<br>
		&nbsp;&nbsp;③ 선택하신 상품의 수량을 변경하시려면 수량변경 후 [변경] 버튼을 누르시면 됩니다.<br>
		&nbsp;&nbsp;④ [쇼핑계속하기] 버튼을 누르시면 쇼핑을 계속 하실 수 있습니다.<br>
		&nbsp;&nbsp;⑤ 장바구니와 관심상품을 이용하여 원하시는 상품만 주문하거나 관심상품으로 등록하실 수 있습니다.<br>
		&nbsp;&nbsp;⑥ 파일첨부 옵션은 동일상품을 장바구니에 추가할 경우 마지막에 업로드 한 파일로 교체됩니다.<br><br><br>
	&nbsp; 무이자할부 이용안내 <br><br>
		&nbsp;&nbsp;① 상품별 무이자할부 혜택을 받으시려면 무이자할부 상품만 선택하여 [주문하기] 버튼을 눌러 주문/결제 하시면 됩니다.<br>
		&nbsp;&nbsp;② [전체 상품 주문] 버튼을 누르시면 장바구니의 구분없이 선택된 모든 상품에 대한 주문/결제가 이루어집니다.<br>
		&nbsp;&nbsp;③ 단, 전체 상품을 주문/결제하실 경우, 상품별 무이자할부 혜택을 받으실 수 없습니다.<br>
		<br>
	</div>

<div id="footer">
	<a><img src="./image/footer.jpg"></a>
	</div>
	</div>
	</body>
</html>