
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="http://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css" />
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<script type="text/javascript" src="datepicker/js/jquery.ui.datepicker-ko.js"></script>
<script type="text/javascript" src="datepicker/js/calendar2.js"></script>
<SCRIPT language=javascript>
 
$(function() {
 
$.datepicker.regional['ko'] = {
closeText: '닫기',
prevText: '이전',
nextText: '다음',
currentText: '오늘',
monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
dayNames: ['일','월','화','수','목','금','토'],
dayNamesShort: ['일','월','화','수','목','금','토'],
dayNamesMin: ['일','월','화','수','목','금','토'],
weekHeader: 'Wk',
dateFormat: 'yy-mm-dd',
firstDay: 0,
isRTL: false,
showMonthAfterYear: true,
yearSuffix: '',
changeYear : true,
changeMonth: true // 월선택 select box 표시 (기본은 false)
};
$.datepicker.setDefaults($.datepicker.regional['ko']);
 
$( "#from_date" ).datepicker();
 
$( "#to_date" ).datepicker();
 
});

function fnCheck(){
    var from_date = $("#from_date").val();
    var array_data_from = from_date.split("-");
    var year_from = array_data_from[0];
    var month_from = array_data_from[1];
    var day_from = array_data_from[2];
    
    var to_date = $("#to_date").val();
    var array_data_to = to_date.split("-");
    var year_to = array_data_to[0];
    var month_to = array_data_to[1];
    var day_to = array_data_to[2];
    
    var today_date = new Date();
    var date_2008 = new Date("2008","01","01");
    var start_date = new Date(year_from, month_from, day_from); 
    var start_date_3 = new Date(year_from, (month_from+3), day_from); 
    var end_date = new Date(year_to, month_to, day_to); 
    if(date_2008.getTime() > start_date.getTime() ) { 
        alert('시작날짜 설정을 다시해주세요');
        $("#from_date").val("");
        return;
    } 
    if(date_1999.getTime() > end_date.getTime() ) { 
        alert('마지막날짜 설정을 다시해주세요');
        $("#to_date").val("");
        return;
    } 
    if(start_date.getTime() < end_date.getTime() && start_date_3.getTime() > end_date.getTime() ) { 
        alert('날짜 설정을 다시해주세요');
        $("#from_date").val("");
        $("#to_date").val("");
        return;
    }
}
</script>
 
 
</SCRIPT>
<style type="text/css">
.container#body{
            position: relative;
            top: 5rem;
            width: 50rem;
        }
</style>
</HEAD>
<BODY>
<div class="container" id="body">
<form name=fmemberlist method=get style="margin:0;">
<input type="button" name="today" value="오늘">
<input type="button" name="week" value="1주일">
<input type="button" name="m_1" value="1개월">
<input type="button" name="m_3" value="3개월">
<input type="button" name="m_6" value="6개월">

<input type="text" id="from_date" name="from_date" value="<?=$from_date?>" readOnly/>~
<input type="text" id="to_date" name="to_date" value="<?=$to_date?>" readOnly />
<input type="submit" value="검색" onclick="fnCheck()" />
</form>
</div>
</BODY>
</HTML>