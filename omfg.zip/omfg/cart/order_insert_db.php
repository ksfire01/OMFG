<?php
$con = mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");
    $order_day = date("Y-m-d");  // 현재의 '년-월-일-시-분'을 저장
    $sql = "select count(*) from order_list_tb where order_day='$order_day'";
    $res = mysqli_fetch_array(mysqli_query($con, $sql));
    $order_count = $res['count(*)']+1;
    $order_num = date("Ymd")."-".$order_count;
if($_POST['form_receiver_type']=="equal"){
    $receiver = $_POST['form_receiver_e'];
    $addr = $_POST['form_addr1_e']." ".$_POST['form_addr2_e']." ".$_POST['form_addr3_e'];
    $phone = $_POST['form_phone1_e']."-".$_POST['form_phone2_e']."-".$_POST['form_phone3_e'];
    $message = $_POST['form_message_e'];
}else{
    $receiver = $_POST['form_receiver_d'];
    $addr = $_POST['form_addr1_d']." ".$_POST['form_addr2_d']." ".$_POST['form_addr3_d'];
    $phone = $_POST['form_phone1_d']."-".$_POST['form_phone2_d']."-".$_POST['form_phone3_d'];
    $message = $_POST['form_message_d'];
}
    $userid=$_POST['form_userid'];
    $totalprice=$_POST['form_totalprice'];
    $pay_method = $_POST['form_pay_method'];
    
    $sql="insert into order_list_tb(order_num, order_day, total_price, state, userid, receiver, address, message, pay_method, phone, date_col)";
    $sql.="values('$order_num' ,'$order_day', $totalprice, '주문접수중', '$userid', '$receiver', '$addr', '$message', '$pay_method', '$phone', '$order_day')";    
    mysqli_query($con, $sql);
    
    
    $count=$_POST['form_count'];
for($i=0;$i<$count;$i++){
    $product_code[$i] = $_POST['form_product_code'.$i];
    $size[$i] = $_POST['form_size'.$i];
    $color[$i] = $_POST['form_color'.$i];
    $buy_quantity[$i] = $_POST['form_buy_quantity'.$i];
    $buy_price[$i] = $_POST['form_buy_price'.$i];
    $point[$i] = $_POST['form_point'.$i];
    
    $sql="insert into buytbl(order_num, userid, product_code, size, color, buy_quantity, buy_price)";
    $sql.="values('$order_num', '$userid', '$product_code[$i]', '$size[$i]', '$color[$i]', $buy_quantity[$i], $buy_price[$i])";    
    mysqli_query($con, $sql) or mysqli_error($con);
    $sql="update product_list_tb set inventory=inventory-$buy_quantity[$i], inventory_out=inventory_out+$buy_quantity[$i] where product_code='$product_code[$i]'";
    mysqli_query($con, $sql);
    $sql="update member_table set point=point+$point[$i] where userid = '$userid'";
    mysqli_query($con, $sql);
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
     <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
     <style type="text/css">
     .container#body{
            position: relative;
            top: 8rem;
            width: 100rem;
        }
     </style>
     </head>
     <body>
     <?php include '../top/top.php'; 
    unset($_SESSION['cart']);?>

     <div class="container" id="body">
     <div class="card text-center">
     <div class="card-body">
    	<h4 class="card-title">주문이 완료되었습니다.</h4>
    	<p class="card-text">주문번호 : <?=$order_num ?></p>
    	<a href="../newfile.php" class="btn btn-dark">계속 쇼핑하기</a>
  		</div>
     </div>
     
     </div>
     
     </body>