<?php
include './include/common.php';
session_start();
// -----장바구니 삭제-----#
if (isset($_SESSION['cart']))
    unset($_SESSION['cart']); // 세션해제
echo ("
    <script>
	      location.href='cart.php';
	 </script>");
?>
