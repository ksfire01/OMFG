<?php
@extract($_POST);//extract() : 배열속의 키값들을 변수화를 진행하는 함수
@extract($_GET);
@extract($_FILES);
@extract($_COOKIE);
@extract($_SESSION);
@extract($_SERVER);
@extract($_ENV);

$con=mysqli_connect("localhost", "root", "123456", "shopDB") or die("MySQL 접속 실패 !!");
echo "MySQL 접속 성공";
?>