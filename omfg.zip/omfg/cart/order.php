<?PHP
include './include/common.php';
include "./include/class.inc";
include '../top/top.php';
session_start();
$con = mysqli_connect("localhost", "root", "123456", "shopdb") or die("MySQL 접속 실패 !!");

if(isset($_SESSION['userid'])){
    $userid=$_SESSION['userid'];
}
if (isset($_POST['id'])) {
    $id = $_POST['id'];
}
if (isset($_POST['size'])) {
    $size = $_POST['size'];
}
if (isset($_POST['color'])) {
    $color = $_POST['color'];
}
if (isset($_POST['buy_quantity'])) {
    $buy_quantity = $_POST['buy_quantity'];
}
if (isset($_POST['buy_price'])) {
    $buy_price = $_POST['buy_price'];
}
if (isset($_POST['point'])) {
    $point = $_POST['point'];
}
if (isset($_POST['product_name'])) {
    $product_name = $_POST['product_name'];
}
if (isset($_GET['code'])) {
    $code = $_GET['code'];
} else {
    $code ="";
}

if (! isset($_SESSION['cart'])) {
    $_SESSION['cart'] = new Cart();
}

$sql2 = "select * from member_table where userid='$userid'";
$res = mysqli_query($con, $sql2);
$row = mysqli_fetch_array($res);
$username=$row['username'];
$tel = explode("-", $row['tel']);
$h1 = $tel[0];
$h2 = $tel[1];
$h3 = $tel[2];
$post = $row['post'];
$addr1 = $row['addr1'];
$addr2 = $row['addr2'];
$email = $row['email'];
$point = $row['point'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>주문</title>
<link href = "./include/order.css" rel="stylesheet" type="text/css" media="all">
 <link href="../bootstrap-4.0.0-beta-dist/css/bootstrap.min.css" rel="stylesheet">
<style type="text/css">
.container#body{
            position: relative;
            top: 0rem;
            width: 62rem;
        }
</style>
<script src="http://dmaps.daum.net/map_js_init/postcode.v2.js"></script>
<script type="text/javascript">
function search_post() {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var fullAddr = ''; // 최종 주소 변수
                var extraAddr = ''; // 조합형 주소 변수

                // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    fullAddr = data.roadAddress;

                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    fullAddr = data.jibunAddress;
                }

                // 사용자가 선택한 주소가 도로명 타입일때 조합한다.
                if(data.userSelectedType === 'R'){
                    //법정동명이 있을 경우 추가한다.
                    if(data.bname !== ''){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있을 경우 추가한다.
                    if(data.buildingName !== ''){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 조합형주소의 유무에 따라 양쪽에 괄호를 추가하여 최종 주소를 만든다.
                    fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('zip_2').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('addr_1_2').value = fullAddr;

                // 커서를 상세주소 필드로 이동한다.
                document.getElementById('addr_2_2').focus();
            }
        }).open();
    }
    function delivery_select(id){
    	if(id=="eq"){
    		document.all["equl"].style.display='';
    		document.all["diff"].style.display="none";
    		document.getElementById("form_receiver_type").value="equal";
    	}else{
    		document.all["equl"].style.display="none";
    		document.all["diff"].style.display='';
    		document.getElementById("form_receiver_type").value="different";
    	}
    }
    
    function pay_met(id){
    	if(id=="card"){
    		document.all["card"].style.display='';
    		document.all["phone"].style.display="none";
    		document.all["cash"].style.display="none";
    	}else if(id=="phone"){
    		document.all["card"].style.display="none";
    		document.all["phone"].style.display='';
    		document.all["cash"].style.display="none";
    	}else{
    		document.all["card"].style.display="none";
    		document.all["phone"].style.display="none";
    		document.all["cash"].style.display='';
    	}
    	document.getElementById("form_pay_method").value = id;
    }
</script>
</head>
<body>
<div class="container" id="body">
<form name="cart" method="post" action="order_insert_db.php">
<?php 
if ($_SESSION['cart']->get_count()) {
    $contents = $_SESSION['cart']->get_list();

    ?>
<div id="header" style="font-size : 30px">ORDER</div>
<div id="benefit">혜택정보&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;가용 적립금 : <?=$point?><strong>P</strong></div>
<div id="order_in">주문상품정보</div>
	<div id="checkbox"><input type="checkbox"></div>
    <div id="product_image">이미지</div>
    <div id="infomation">상품정보</div>
    <div id="price_">상품구매금액</div>
    <div id="quantity_">수량</div>
    <div id="product_point">적립금</div>
    <div id="deliverycharge">배송비</div>
    <div id="total_price">합계</div>
	<?php 
    	$sum = 0;
    	$count=0;
    	while (list ($id, $value) = each($contents)) {
            $sql = "select fpicture from product_page_tb where product_name='$value[0]'";
            $row = mysqli_fetch_array(mysqli_query($con, $sql));
            $fpicture = $row['fpicture'];
    	    $sm_sum = $value[3] * $value[4]; // 합계 = 수량 * 가격
    	    $sum += $sm_sum; // 전체 합계
	?>
	<div id="checkbox02"><input type="checkbox"></div>
    <div id="product_image_2"><img alt="" src=<?php echo "../picture/$fpicture"?> style="height: 100px; width: 120px;"></div>
    <div id="infomation_2">상품명 : <?=$value[0]?><br>사이즈 : <?=$value[1]?><br>색상 : <?=$value[2]?></div>
    <div id="price_2"><?=$value[4]?> 원</div>
    <div id="quantity_2"><?=$value[3]?> 개</div>
    <div id="product_point_2"><?=$value[5]*$value[3]?></div>
    <div id="deliverycharge_2">무료</div>
    <div id="total_price_2">총 : <?=$sm_sum?>원</div>
    
    <input type="hidden" name=<?php echo "form_product_code".$count?> value=<?php echo $id?>>
    <input type="hidden" name=<?php echo "form_size".$count?> value=<?php echo $value[1]?>>
    <input type="hidden" name=<?php echo "form_color".$count?> value=<?php echo $value[2]?>>
    <input type="hidden" name=<?php echo "form_buy_quantity".$count?> value=<?php echo $value[3]?>>
    <input type="hidden" name=<?php echo "form_buy_price".$count?> value=<?php echo $sm_sum?>>
    
    
<?php 
    $count++;
    	}
?>
	<!-- start order_info -->
    <div id="order_info"><h5>&nbsp;&nbsp;주문자 정보</h5>
    <div id="one">
    <div id="order_name">주문하시는분 <strong>*</strong></div>
    <div id="txt_name"><input type="text" id="odname" value="<?=$username?>" readonly></div>
    </div>
    
    <div id="two">
    <div id="addr">주소  <strong>*</strong></div>
    <div id="addr_form"><input type="text" id="zip" value="<?=$post?>" readonly><input type="button" value="우편번호"><br>
    <div id="addr_e"><input type="text" id="addr_1" value="<?=$addr1?>" readonly><br> </div>
    <div id="addr_e2"><input type="text" id="addr_2" value="<?=$addr2?>" readonly></div>
    </div>
    </div>
    
    <div id="three">
    <div id="telnum">전화번호  <strong>*</strong></div>
    <div id="phone"><select name="tel" id="phone1">
    	<option value="010" selected>010</option>
    	<option value="011">011</option>
    	<option value="016">016</option>
    	<option value="017">017</option>
    	<option value="019">019</option>
    	<option value="02">02</option>
    	<option value="031">031</option>
    	<option value="032">032</option>
    	<option value="033">033</option>
    	<option value="041">041</option>
    	<option value="042">042</option>
    	<option value="043">043</option>
    	<option value="051">051</option>
    	<option value="052">052</option>
    	<option value="053">053</option>
    	<option value="054">054</option>
    	<option value="055">055</option>
    	<option value="061">061</option>
    	<option value="062">062</option>
    	<option value="063">063</option>
    	<option value="064">064</option>
    	<option value="044">044</option>
    </select> <div id="phone2"><input type="text" id="p2" value="<?=$h2?>" readonly>-</div> 
    <div id="phone3"><input type="text" id="p3" value="<?=$h3?>" readonly></div>
    </div>
    </div>

    <div id="four">
    <div id="email_form">email <strong>*</strong></div>
    <div id="email"><input type="email" id="email_name" value="<?=$email?>" readonly></div>
    </div>
    </div>
    <!-- end of order_info -->
    
    <div id="sipping_addr"><h5>&nbsp;&nbsp;배송지 정보</h5>
    <div id="select_addr">배송지 선택</div>
    
    <div id="sel">
    <input type='radio' id="eq" class='rad1' checked='checked' name='sel_addr' onclick="delivery_select(id)">주문자 정보와 동일&nbsp;&nbsp;
    <input type='radio' id="df" class='rad2' name='sel_addr' onclick="delivery_select(id)">새로운 배송지
    </div>
    
    <!-- start equl -->
	<div id="equl" style="display:'';">
        <div id='one'>
        <div id='order_name'>받으시는 분 <strong>*</strong></div>
        <div id='txt_name'><input name="form_receiver_e" type='text' id='odname' value="<?=$username?>" readonly></div>
        </div>
        
        <div id='two'>
        <div id='addr'>주소  <strong>*</strong></div>
        <div id='addr_form'><input name="form_addr1_e" type='text' id='zip' value="<?=$post?>" readonly><input type='button' value='우편번호'><br>
        <div id='addr_e'><input name="form_addr2_e" type='text' id='addr_1' value="<?=$addr1?>" readonly><br> </div>
        <div id='addr_e2'><input name="form_addr3_e" type='text' id='addr_2' value="<?=$addr2?>" readonly></div>
        </div>
        </div>
        
        <div id='three'>
        <div id='telnum'>전화번호  <strong>*</strong></div>
        <div id='phone'><select name='form_phone1_e' id='phone1'>
        	<option value='010' selected>010</option>
        	<option value='011'>011</option>
        	<option value='016'>016</option>
        	<option value='017'>017</option>
        	<option value='019'>019</option>
        	<option value='02'>02</option>
        	<option value='031'>031</option>
        	<option value='032'>032</option>
        	<option value='033'>033</option>
        	<option value='041'>041</option>
        	<option value='042'>042</option>
        	<option value='043'>043</option>
        	<option value='051'>051</option>
        	<option value='052'>052</option>
        	<option value='053'>053</option>
        	<option value='054'>054</option>
        	<option value='055'>055</option>
        	<option value='061'>061</option>
        	<option value='062'>062</option>
        	<option value='063'>063</option>
        	<option value='064'>064</option>
        	<option value='044'>044</option>
        </select> <div id='phone2'><input name="form_phone2_e" type='text' id='p2' value="<?=$h2?>">-</div> 
        <div id='phone3'><input name="form_phone3_e" type='text'id='p3' value="<?=$h3?>"></div>
        </div>
        </div>
    	
    	<div id='five'>
    	<div id='message'>배송메세지</div>
    	<div id='content'><textarea name="form_message_e" rows='2' cols='40' id='txta'></textarea></div>
    	</div>
    	</div> <!-- end of equl -->
    	
    	<!-- start diff -->
    	<div id="diff" style="display:none">
    		<div id='one'>
            <div id='order_name'>받으시는 분 <strong>*</strong></div>
            <div id='txt_name'><input name="form_receiver_d" type='text' id='odname'></div>
            </div>
        
            <div id='two'>
            <div id='addr' >주소  <strong>*</strong></div>
            <div id='addr_form_2'><input name="form_addr1_d" type='text' id='zip_2'><input type='button' value='우편번호' onclick="search_post();"><br>
            <div id='addr_e_2'><input name="form_addr2_d" type='text' id='addr_1_2'><br> </div>
            <div id='addr_e2_2'><input name="form_addr3_d" type='text' id='addr_2_2'></div>
            </div>
            </div>
            
            <div id='three'>
            <div id='telnum'>전화번호  <strong>*</strong></div>
            <div id='phone'><select name="form_phone1_d" id='phone1'>
            	<option value='010' selected>010</option>
            	<option value='011'>011</option>
            	<option value='016'>016</option>
            	<option value='017'>017</option>
            	<option value='019'>019</option>
            	<option value='02'>02</option>
            	<option value='031'>031</option>
            	<option value='032'>032</option>
            	<option value='033'>033</option>
            	<option value='041'>041</option>
            	<option value='042'>042</option>
            	<option value='043'>043</option>
            	<option value='051'>051</option>
            	<option value='052'>052</option>
            	<option value='053'>053</option>
            	<option value='054'>054</option>
            	<option value='055'>055</option>
            	<option value='061'>061</option>
            	<option value='062'>062</option>
            	<option value='063'>063</option>
            	<option value='064'>064</option>
            	<option value='044'>044</option>
            </select> <div id='phone2'><input name="form_phone2_d" type='text' id='p2'>-</div> 
            <div id='phone3'><input name="form_phone3_d" type='text'id='p3'></div>
            </div>
            </div>
        	
        	<div id='five'>
        	<div id='message'>배송메세지</div>
        	<div id='content'><textarea name="form_message_d" rows='2' cols='40' id='txta'></textarea></div>
        	</div>
    	</div><!-- end of diff -->
	</div><!-- end of sippind_addr -->

	
	<!-- start all -->
	<div id="all">
	<div id="total_p"><strong>총 상품금액</strong></div>
	<div id="total_dp"><strong>총 배송비</strong></div>
	<div id="pay"><strong>결제예정금액</strong></div>
	
	<div id="total_p_2">KRW <b><?=$sum?></b></div>
	<div id="total_dp_2">+ KRW <b>0</b></div>
	<div id="pay_2">=KRW <b><?=$sum?></b></div>
	</div>
	<!-- end of all -->
	
	<!-- start last -->
	<div id="last">
	<div id="pay_method">결제수단
	<div id="select_method">
	<input type="radio" value="method_card" checked="checked" name="method" onclick="pay_met(id)"> 카드 결제 &nbsp;&nbsp; 
	<input type="radio" value="method_phone" name="method" onclick="pay_met(id)"> 휴대폰 결제&nbsp;&nbsp;
	<input type="radio" value="method_cash" name="method" onclick="pay_met(id)"> 무통장 입금
	</div>
	
	</div>
	<div id="result_pay">최종 결제 금액
	<div id="krw">KRW</div>
	<div id="last_pay"><?=$sum?></div>
	<input id="form_userid" type="hidden" name="form_userid" value=<?php echo $userid?>>
	<input id="form_totalprice" type="hidden" name="form_totalprice" value=<?php echo $sum?>>
	<input id="form_count" type="hidden" name="form_count" value=<?php echo $count?>>
	<input id="form_receiver_type" type="hidden" name="form_receiver_type" value="equal">
	<input id="form_pay_method" type="hidden" name="form_pay_method" value="card">
	<div id="paybutton"><button type="submit" id="pay_btn" value="">결제하기</button></div>
	</div>
	</div> 
	<!-- end of last -->
	
<?php 
} else {
    echo ("<br><br><p id='empty_order' align=center><font id='aa'>현재 주문내역이 없습니다.</font></p>");
    unset($_SESSION['cart']); // 세션해제
}
?>
<div id="lbtn">
	<input type='button' id='order_history' value='지난 주문 내역 확인'
		onclick="javascript:location='./my_buy.php'">
	<input type="button" id="con_btn" value="쇼핑하러가기" 
		onclick="javascript:location='../newfile.php'">
</div>
	<div id="footer">
	<a><img src="./image/footer.jpg"></a>
	</div>
</form>
</div>
</body>
</html>