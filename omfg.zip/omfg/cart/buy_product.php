<?PHP
include './include/common.php';
include "./include/class.inc";
/* include '../top/top.php'; */

session_start();
if (isset($_SESSION['shop_logon'])) {
    $shop_logon = $_SESSION['shop_logon'];
    $cur_date = getdate();
    $mem_date = $cur_date[year];
   
    if ($cur_date[mon] < 10)
        $mem_date .= "-0" . $cur_date[mon];
        else
            $mem_date .= "-" . $cur_date[mon];
            
            if ($cur_date[mday] < 10)
                $mem_date .= "-0" . $cur_date[mday];
                else
                    $mem_date .= "-" . $cur_date[mday];
                    
                    $buy_state = '배송준비중';

                    $contents = $_SESSION[cart]->get_list();
                    $buy_id = 0;
                    // -----장바구니에 있는 상품을 buy_tab 테이블에 추가-----#
                    while (list ($id, $value) = each($contents)) {
                        $buy_id = $buy_id + 1;
                        $query = "insert into buytbl VALUES ";
                        $query .= "(null ,'$order_num', '$userid', '$product_code', '$size', '$color', $buy_quantity, $buy_price)";
                        $result = mysqli_query($con, $query);
                        if (! $result) {
                            echo ("
	          <script>
	              window.alert('오류가 발생하였습니다. 다시 시도해주세요.');
		          history.go(-1);
		      </script>
	        ");
                            exit();
                        }
                        echo "<meta http-equiv = 'refresh' content = '0;url=./cart_delete.php'>";
                    }
}
else {
    echo ("
	      <script>
	        window.alert('먼저 로그인을 해야합니다.');
	        location.href='../login/login/login_form.php';
	      </script>
	    ");
}
?>
