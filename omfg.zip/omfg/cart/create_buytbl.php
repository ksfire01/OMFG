<?php
include "./include/common.php";

$flag = "NO";

$sql = "SHOW TABLES FROM shopDB";
$result = mysqli_query($con, $sql);
if (! $result) {
    echo "DB Error, could not list tables\n";
    echo 'MySQL Error: ' . mysqli_error();
    exit();
}

while ($row = mysqli_fetch_row($result)) {
    if ($row[0] == "buytbl") {
        $flag = "OK";
        break;
    }
}

/* 테이블이 존재하지 않으면 테이블생성 */
if ($flag != "OK") {
    $sql = "CREATE TABLE buytbl(
        num int(10) auto_increment primary key,
        order_num varchar(20),
        userid varchar(10) default ' ' not null,
        product_code varchar(10),
        size varchar(10),
        color varchar(10),
        buy_quantity int(10),
        buy_price int(10),
        foreign key(order_num) references order_list_tb(order_num),
        foreign key(product_code) references product_list_tb(product_code))";

    $result = mysqli_query($con, $sql) or die("<font size=4><br><center>buytbl생성중 오류</font><hr>
    <script>
		alert('[buytbl 테이블생성중 오류] 테이블 생성중 오류; ');
    </script>");
    if (! $result) {
        echo "DB Error, MySQL Error: ".mysqli_error();
        exit();
    }
}
echo "<font size=4><br><center>buytbl 성공적으로 만듬</font><hr>
        <script>
        alert('[테이블생성성공] buytbl 테이블 생성');
        location.replace('./newfile.php');
		</script>";
mysqli_close($con); // db연결 종료
?>
