<?php

$scale=4;//한 grid 안에 표시되는 목록 수
$gscale=3;//한 화면에 표시되는 grid수

include './lib/dbconn.php';
$type=$_GET["type"];

if(isset($_SESSION['shop_logon']))
$shop_logon=$_SESSION['shop_logon'];

$sql="select * from product_page_tb where product_type='$type' order by num desc";
$result=mysqli_query($con,$sql);

$total_record=mysqli_num_rows($result);//전체 글 수

//전체 페이지 수 ($total_page)계산
if($total_record%$scale==0){
  $total_page=floor($total_record/12);
}
else{
  $total_page=floor($total_record/12)+1;
}
if(empty($page)){ //페이지번호($page)가 0 일 때
  $page=1; //페이지 번호를 1로 초기화
}
//표시할 페이지($pgae)에 따라 $start 계산
$start=($page-1)*$scale;
$number=$total_record-$start;


 ?>
 <!DOCTYPE html>
 <html>
 <title>OMFG</title>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
 <style>
 body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
 .w3-bar-block .w3-bar-item {padding:20px}
 #bodycontent{
   position : relative;
   top : 8em;
   
 }
 #new-arrival{
            font-family: "Century Gothic";
            font-size: 2em;
            text-align: center;
            text-decoration: underline;
        }

 </style>
 <body>

 <!-- Sidebar (hidden by default) -->
 <?php
    include '../top/top.php';
 ?>

 <div class="w3-top">
   <div class="w3-white w3-xlarge" style="max-width:1500px;margin:auto">

     <div class="w3-right w3-padding-16">outer</div>

   </div>
 </div>

 <!-- !PAGE CONTENT! -->
 <div class="w3-main w3-content w3-padding" id="bodycontent" style="max-width:1400px;">
 <div class="col-md-12">
	<p id="new-arrival"><?php switch ($type){
	    case "o" : echo "O U T E R"; break;
	    case "t" : echo "T O P"; break;
	    case "b" : echo "B O T T O M"; break;
	    case "s" : echo "S H O E S / B A G"; break;
	    case "a" : echo "A C C"; break;
	}?></p>
</div>
<?php
 $count=0;
for($i=$start;$i<$start+12&&$i<$total_record;$i++){
 ?>
   <!-- First Photo Grid-->
   <div class="w3-row-padding w3-padding-16 w3-center" id="food">
     <?php
     for($j=0;$j<$scale;$j++){
       mysqli_data_seek($result,$count);
       $row=mysqli_fetch_array($result);
       $suit_num=$row['num'];
       $suit_name=$row['product_name'];
       $suit_price=$row['price'];
       $suit_fpicture=$row['fpicture'];
       $count++;
       
?>
     <div class="w3-quarter">
       <a href="../detail/detailpage.php?name=<?=$suit_name?>"><img src="../picture/<?=$suit_fpicture?>" style="width:110%; padding:1em;"></a>
       <p style="font-size:20px; margin-bottom:0em;"><?=$suit_name?></p>
       <p style="font-size:15px; vertical-align:top;"><?=$suit_price?></p>
     </div>
<?php } ?>
   </div>
<?php } ?>

   <!-- Pagination -->
   <div class="w3-center w3-padding-32">
     <div class="w3-bar" style="width:100%; overflow:hidden">
       <class="w3-bar-item w3-button w3-hover-black">«</a>

      <?php
        for($k=1;$k<=$total_page;$k++){
          if($page==$k){
            echo"<class='w3-bar-item w3-black w3-button'>$k";
          }
          else{
            echo"<class='w3-bar-item w3-button w3-hover-black'><a href='suitlist.php?page=$k&type=$type'>$k</a>";
          }
        }
?>
       <class="w3-bar-item w3-button w3-hover-black">»</a>
     </div>
   </div>

   <hr id="about">

   <!-- Footer -->
   <footer class="w3-row-padding w3-padding-32">


   </footer>

 <!-- End page content -->
 </div>

 <script>
 // Script to open and close sidebar
 function w3_open() {
     document.getElementById("mySidebar").style.display = "block";
 }
 function w3_close() {
     document.getElementById("mySidebar").style.display = "none";
 }
 </script>
 </body>
 <?php if(isset($_SESSION['userid'])&&$_SESSION['userid']=="admin") include '../top/manager_nav.php';?>
 <footer class="text-muted">
	<img src="../img/footer.jpg" style="width: 100%; height: 30rem;">
  </footer>
 </html>
