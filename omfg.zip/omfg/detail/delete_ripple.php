<?php
      include "./lib/dbconn.php";
      $name=$_GET['name'];
      $num=$_GET['num'];
      $sql = "delete from boardripple where num=$num";
      mysqli_query($con,$sql);
      mysqli_close($con);

      echo "
	   <script>
	    location.href = 'detailpage.php?name=<?=$name?>';
	   </script>
	  ";
?>
