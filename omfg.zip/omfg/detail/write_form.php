	<?php
	
	include '../top/top.php';
	include "./lib/dbconn.php";
	if(isset($_SESSION['userid']))
	$userid=$_SESSION['userid'];

	$name=$_GET['name'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="./include/common.css" rel="stylesheet" type="text/css" media="all">
<link href="./include/board4.css" rel="stylesheet" type="text/css" media="all">
<script>
  function check_input()
   {
      if (!document.board_form.subject.value)
      {
          alert("제목을 입력하세요1");
          document.board_form.subject.focus();
          return;
      }

      if (!document.board_form.content.value)
      {
          alert("내용을 입력하세요!");
          document.board_form.content.focus();
          return;
      }
      document.board_form.submit();
   }
</script>
</head>

<body>
	<?php
		
	?>
<div id="wrap">
  <div id="header">

  </div>  <!-- end of header -->


	<div id="col2" style="margin-top:5em;">

		<div class="clear"></div>
		<form  name="board_form" method="post" action="insert.php?name=<?=$name?>" enctype="multipart/form-data">

		<div id="write_form">
			<div class="write_line"></div>
			<div id="write_row1"><div class="col1">아이디</div>
			<div class="col2">
		<?=$userid?></div>
</div>


			<div class="write_line"></div>
			<div id="write_row2" style="height: 2.3em;"><div class="col1"> 제목  </div>
			                     <div class="col2"><input type="text" name="subject" value="<?php echo isset($item_subject)?$item_subject:""?>" ></div>
			</div>
			<div class="write_line"></div>
			<div id="write_row3" style="height:10.5em;">
			<div class="col1" style="padding-top:5em;"> 내용   </div>
			                     <div class="col2"><textarea rows="6" cols="79" name="content"><?php echo isset($item_content)?$item_content:""?></textarea></div>
			</div>
			<div class="write_line"></div>
			<div id="write_row4"><div class="col1"> 이미지파일1   </div>
			                     <div class="col2"><input type="file" name="upfile[]"></div>
			</div>
			<div class="clear"></div>
<?php 	if (isset($item_file_0))
	{
?>
			<div class="delete_ok"><?=$item_file_0?> 파일이 등록되어 있습니다. <input type="checkbox" name="del_file[]" value="0"> 삭제</div>
			<div class="clear"></div>
<?php
	}
?>
			<div class="write_line"></div>
			<div id="write_row5"><div class="col1"> 이미지파일2  </div>
			                     <div class="col2"><input type="file" name="upfile[]"></div>
			</div>
<?php 	if (isset($item_file_1))
	{
?>
			<div class="delete_ok"><?=$item_file_1?> 파일이 등록되어 있습니다. <input type="checkbox" name="del_file[]" value="1"> 삭제</div>
			<div class="clear"></div>
<?php
	}
?>
			<div class="write_line"></div>
			<div class="clear"></div>
			<div id="write_row6"><div class="col1"> 이미지파일3   </div>
			                     <div class="col2"><input type="file" name="upfile[]"></div>
			</div>
<?php 	if (isset($item_file_2))
	{
?>
			<div class="delete_ok"><?=$item_file_2?> 파일이 등록되어 있습니다. <input type="checkbox" name="del_file[]" value="2"> 삭제</div>
			<div class="clear"></div>
<?php
	}
?>
			<div class="write_line"></div>

			<div class="clear"></div>
		</div>

		<div id="write_button"><a href="#"><img src="./photo/ok.png" onclick="check_input()"></a>&nbsp;
								<a href="detailpage.php?name=<?=$name?>"><img src="./photo/list.png"></a>
		</div>
		</div>
		</form>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->

</body>
</html>
