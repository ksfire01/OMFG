<?php


$con=mysqli_connect("localhost","root","123456","shopDB") or
die("SQL sever에 연결할 수 없습니다.");


 ?>
