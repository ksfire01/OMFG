<?php
session_start();
include './lib/dbconn.php';
if(isset($_SESSION['userid']))
$userid=$_SESSION['userid'];


$name=$_GET['name'];
$mode=isset($_GET['mode'])?$_GET['mode']:"";
$sql="select * from product_page_tb where product_name='".$name."'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);

$detail_num=$row['num'];
$detail_name=$row['product_name'];
$detail_type=$row['product_type'];
$detail_price=$row['price'];
$detail_point=$row['point'];
$detail_colors=$row['colors'];
$detail_sizes=$row['sizes'];
$detail_info=$row['info'];
$detail_fabric=$row['fabric'];
$detail_model=$row['model'];
$detail_recommended=$row['recommended'];
$detail_fpicture=$row['fpicture'];
$detail_dpicture1=$row['dpicture1'];
$detail_dpicture2=$row['dpicture2'];
$detail_dpicture3=$row['dpicture3'];
$detail_dpicture4=$row['dpicture4'];
$detail_dpicture5=$row['dpicture5'];
$detail_dpicture6=$row['dpicture6'];
$detail_dpicture7=$row['dpicture7'];
$detail_dpicture8=$row['dpicture8'];
$detail_dpicture9=$row['dpicture9'];
$detail_dpicture10=$row['dpicture10'];
$detail_registday=$row['registday'];

$detail_info=str_replace(" ","&nbsp;",$detail_info);
$detail_info=str_replace("\n","<br>",$detail_info);

 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     <title></title>
     <script type="text/javascript"> 
     function chk(){ 
      var cidx = color_form.color_select.options.selectedIndex; 
      var sidx = size_form.size_select.options.selectedIndex;
      var cvalue=color_form.color_select.options[cidx].value;
      var svalue=size_form.size_select.options[sidx].value;
      var box=document.getElementById("ob");


      if(cvalue&&svalue){

       box.style.display="block";
       bcost.innerHTML=
         "<h5><b>"+document.getElementById("detail_price").value+"</b></h5>";
     }else{
       alert("다시 확인해 주세요.");
     }
     } 

     </script> 


     <style>
     body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
     #bodycontent{
       position : relative;
       top : 8em;
     }
     #ob{
       width:75ex;
       height: 10ex;
       border-bottom:1px solid gray;
     }
     #list_top_title {
      width:75em;
     	height:40px;
     	border-top:solid 2px #aaaaaa;
     	background-color:#eeeeee;
      padding-top:0em;
     	margin-bottom:3px;
     }
     #Q{
       margin-left:15em; margin-top:15em; margin-bottom:2em; font-size:80%;
     }
     #Qb{
       margin-left: 10em;font-size:110%; margin-bottom:0.5em;
     }
     #list_top_title li {
     	display:inline;
     }

     #list_top_title #list_title1 {
     	margin-left:5px;
     }

     #list_top_title #list_title2 {
     	margin-left:250px;
     }

     #list_top_title #list_title3 {
     	margin-left:290px;
     }

     #list_top_title #list_title4 {
     	margin-left:32px;
     }

     #list_top_title #list_title5 {
     	margin-left:26px;
     }
     #list_content {
     	height:auto;
     }

     #ripple_writer_title{
       border-bottom:solid 1px #eeeeee;
       padding-top: 0.5em;
     }
     #list_item {
       width:75em;
     	margin-top:2px;
     	padding:6px;
     	border-bottom:solid 1px #eeeeee;
     }

     #list_item #list_item1{
     	float:left;
     	width:110px;
     	text-align:center;
     }

     #list_item #list_item2{
     	float:left;
     	width:525px;
     }

     #list_item #list_item3{
     	float:left;
     	width:70px;
     	text-align:center;
     }

     #list_item #list_item4{
     	float:left;
     	width:80px;
     	text-align:center;
     }

     #list_item #list_item5{
     	float:left;
     	width:40px;
     	text-align:center;
     }
     #list_item #list_item6{

       width:75em;
       text-align:center;
       padding-left:20em;
     }
     #page_button {
     	margin-top:20px;
     }

     #page_num {
     	float:left;
     	width:80%;
     	margin-top:10px;
     	text-align:center;
     }


     </style>
   </head>
   <body>
     <?php
        include '../top/top.php';
     ?>
     <!-- !PAGE CONTENT! -->
<div class="w3-main w3-content w3-padding" id="bodycontent" style="max-width:1400px;">

  <div style="margin-bottom:128px">
  <div class="w3-half">
    <img src="../picture/<?=$detail_fpicture?>" style="width:60%; margin-left:12em;">
  </div>

  <div class="w3-half">
    <div>
      <h5 style="margin-top:1em;"><?=$detail_name?></h5>
      <h6 style="font-size:80%; margin:0;">KRW <?=$detail_price?></h6>
      <input type="hidden" id="detail_price" value="<?=$detail_price?>">
      <h6 style="font-size:70%; margin-top:1em;"> <?=$detail_point?>원
        <?php
        $a=floor(($detail_price/$detail_point)/100);
        echo "(".$a."%)";
         ?>
      </h6>
      <input type="hidden" id="detail_point" value="<?=$detail_point?>">
      <input type="hidden" id="detail_point_percent" value="<?=$a?>">

      <div style="margin-top:1em;">
        <div style="float:left; width:10em; font-size:90%; padding-top:2px;">
          색상
        </div>
        <div>
          <?php
          $colors=explode(",",$detail_colors);
           ?>
           <form name="color_form" method="post">
             <select name="color_select" style="width:24em" >
               <option>-[필수] 옵션을 선택해 주세요</option>
               <?php
               for($i=0;$i<sizeof($colors);$i++){
                 echo "<option value='$colors[$i]'>$colors[$i]</option>";}
                 ?>
               </select>
           </form>
        </div>
      </div>

      <div style="margin-top:3px;">
        <div style="float:left; width:10em; font-size:90%; padding-top:2px;">
          사이즈
        </div>
        <div>
          <?php
          $sizes=explode(",",$detail_sizes);
           ?>
           <form name="size_form" method="post" onchange="chk();">
             <select name="size_select" style="width:24em" >
               <option>-[필수] 옵션을 선택해 주세요</option>
               <?php
               for($i=0;$i<sizeof($sizes);$i++){
                 $size1=explode("-",$sizes[$i]);
                 echo "<option value='$size1[0]'>$size1[0]</option>";}
                 ?>
               </select>
           </form>
        </div>
      </div>

      <div style="width:37.5em; border-bottom:1px solid gray;">
      <div style="float:left;padding-top:0.8em; padding-right:0.8em;">
        <img src="./photo/1.gif">
      </div>
      <div style="padding-top:2em; padding-bottom:0.5em;font-size:70%; color:red;">
        위 옵션선택 박스를 선택하시면 아래에 상품이 추가됩니다.
      </div>
      </div>

      <div id='ob' style="display:none;">
        <div>
          <div style="float:left; font:90%; width:18em; margin:0.5em;">
            <b><?=$detail_name?></b>
          </br>
          <script>
          var cidx = color_form.color_select.options.selectedIndex; 
          var sidx = size_form.size_select.options.selectedIndex;
          var cvalue=color_form.color_select.options[cidx+1].value;
          var svalue=size_form.size_select.options[sidx+1].value;
          document.write('-'+cvalue+'/'+svalue);
          </script>
          </div>

          <div style="float:left; margin-top:1.5em;">

          <div id="no" style="margin-top:0.2em; width:1em; float:left; font-size:80%; ">
              1
          </div>

          <div>
          <img src="./photo/4.gif" style="margin:0em; padding:0em; float:left;" onclick="add(1)">
          <img src="./photo/5.gif" style="margin:0em; padding:0em; float:left;" onclick="add(-1)">
          </div>
          </div>

          <div style="float:left; margin-top:0.5em;">
            <img src="./photo/3.gif" onclick="d()">
            <script>
              function d(){
                var box=document.getElementById("ob");
                box.style.display="none";
                bcost.innerHTML=
                  "<h5><b>"+0+"</b></h5>";
              }
            </script>
          </div>

            <div style="font-size:80%; margin:1em; margin-left:4em; float:left; ">

              <div id="cost">
                <b>KRW <?=$detail_price?>
                </b>
              </div>
              <div id="point">
                <b>(
                    <img src="./photo/2.gif" style="margin:0px; padding:0px;">
                  <?=$detail_point?>원
                  )</b>
              </div>
            </div>

        <script>
          var sum=document.getElementById("detail_price").value;
          var no=1;
          var point=document.getElementById("detail_point").value;
          function add(num){
            if(num==-1){
              if(no==1){
                alert("최소 구매 수량은 1개입니다.");
                return;
              }
              no--;
            }else if(num==1){
              no++;
            }

            var tno=document.getElementById("no");
            var sumCost=document.getElementById("cost");
            var sumPoint=document.getElementById("point");
            var bcost=document.getElementById("bcost");
            tno.innerHTML=no;
            sumCost.innerHTML="<b>KRW "+sum*no+"</b>";
            sumPoint.innerHTML=
            "<b>(<img src='./photo/2.gif'style='margin:0px;paddind:0px'>"+point*no+"원)</b>";
            bcost.innerHTML=
              "<h5><b>"+sum*no+"</b></h5>";
          }
        </script>

        </div>
      </div>

      <div style="padding-top:1em; padding-bottom:1em;">
        <div style="float:left; font-size:80%;">
          <b>총 상품 금액</b> : &nbsp;
        </div>
        <div id="bcost"style="float:left;">
          <h5><b>0</b></h5>
        </div>
        <div style="float:left; font-size:80%;">
          <b>&nbsp;원</b>
        </div>
      </div>

  <div class="w3-padding-32" style="width:36.15em;">
   <div class="w3-bar w3-border">
     <a href="#" class="w3-bar-item w3-button" style="width:12em;">buy</a>
     <a href="#" class="w3-bar-item w3-button w3-light-grey"style="width:12em;">cart</a>
     <a href="#" class="w3-bar-item w3-button" style="width:12em;">wish</a>
   </div>
 </div>

  <div style="font-size:90%">
    <div style="color:green;">
      INFO
    </div>
    <div>
      <?=$detail_info?>
    </div>
  </div>
  <div style="font-size:90%">
    <div style="color:green;">
      SIZE
    </div>
    <div>
    <?=$detail_sizes?>
    </div>
  </div>
  <div style="font-size:90%">
    <div style="color:green;">
      FEBRIC
    </div>
    <div>
      <?=$detail_fabric?>
    </div>
  </div>
  <div style="font-size:90%">
    <div style="color:green;">
      MODEL
    </div>
    <div>
      <?=$detail_model?>
    </div>
  </div>
      </div>
      <!-- //////////////////////////////////////////////////-->
    </div>
    <div style="margin-left:15em;" >
      <?php
      for($i=1;$i<=10;$i++){
        if(!empty($row['dpicture'.$i])){
      ?>
            <img src="../picture/<?=$row['dpicture'.$i]?>" >
      <?php
        }
      }
       ?>


    <div style="margin-left:10em; font-size:70%; text-align:left;">
      <b>교환 및 반품이 가능한 경우</b><br/>
      -상품을 공급 받으신 날로부터 7일 내 보내주셔야 합니다.
      <br/>
      <br/>
      <b>교환 및 방품이 불가능 한 경우</b><br/>
      -상품 수령 후 7일 이내 교환/반품 접수하지 않은 경우<br/>
      -재판매가 불가한 상품일 경우 (세탁,수선,오염)<br />
      -제품포장 개봉시 칼이나 가위로 고객님 부주위에 의해 상품이 훼손된 경우<br/>
      <br/>
      <br/>
      ※ 고객님의 마음이 바뀌어 교환, 반품을 하실 경우 상품반송 비용은 고객님께서 부담하셔야 합니다.<br/>
      (색상 교환,사이즈 교환 등 포함)
      <br/>
      <br/>
      <br/>
    </div>

    <div style="margin-left:8em; margin-top:3em; margin-bottom:2em; font-size:80% ">
      <b style="font-size:110%; margin-bottom:0.5em;">review</b><br/>
   <?php
   $scale=5;
   $sql="select * from board order by num desc";
   $result2=mysqli_query($con,$sql);
   $total_record=mysqli_num_rows($result2);
   if($total_record%$scale==0)
   $total_page=floor($total_record/$scale);
   else
   $total_page=floor($total_record/$scale)+1;
   if(!isset($page)||$page==0)
   $page=1;
   $start=($page-1)*$scale;
   $number=$total_record-$start;
    ?>
    <div id="list_top_title">
			<ul>
				<li id="list_title1"><img src="./photo/list_title1.gif"></li>
				<li id="list_title2"><img src="./photo/list_title2.gif"></li>
				<li id="list_title3"><img src="./photo/list_title3.gif"></li>
				<li id="list_title4"><img src="./photo/list_title4.gif"></li>
				<li id="list_title5"><img src="./photo/list_title5.gif"></li>
			</ul>
		</div>
    <div id="list_content">
      <?php
      for($i=$start;$i<$start+$scale&&$i<$total_record;$i++){
        mysqli_data_seek($result2,$i);
        $row=mysqli_fetch_array($result2);

        $item_num=$row['num'];
        $item_id=$userid;
        $item_name=$row['productname'];
        $item_hit=$row['hit'];
        $item_date=$row['regist_day'];
        $item_date=substr($item_date,0,10);
        $item_subject=str_replace(" ","&nbsp;",$row['subject']);
        $item_content=$row['content'];
        $item_content=str_replace(" ","&nbsp;",$item_content);
        $item_content=str_replace("\n","<br>",$item_content);
        $image_copied[0] = $row['file_copied_0'];
        $image_copied[1] = $row['file_copied_1'];
        $image_copied[2] = $row['file_copied_2'];
        for ($i=0; $i<3; $i++)
      	{
      		if ($image_copied[$i])
      		{
      			$imageinfo = GetImageSize("./data/".$image_copied[$i]);

      			$image_width[$i] = $imageinfo[0];
      			$image_height[$i] = $imageinfo[1];
      			$image_type[$i]  = $imageinfo[2];

      			if ($image_width[$i] > 785)
      				$image_width[$i] = 785;
      		}
      		else
      		{
      			$image_width[$i] = "";
      			$image_height[$i] = "";
      			$image_type[$i]  = "";
      		}
      	}

      	$new_hit = $item_hit + 1;

      	$sql = "update board set hit=$new_hit where num=$item_num";   // 글 조회수 증가시킴
      	mysqli_query($con, $sql);
       ?>
       <div id="list_item">

     				<div id="list_item1"><?= $number ?></div>
     				<div id="list_item2">
              <a href="#ripplebox" onclick=<?php echo "myFunction('ripplebox".$i."')"?>><?= $item_subject ?></a>
     				</div>
            <div id="list_item3"><?= $userid ?></div>
            <div id="list_item4"><?= $item_date ?></div>
            <div id="list_item5"><?= $item_hit ?></div>

            <div id=<?php echo "ripplebox".$i ?> class="w3-hide">
              <br/>
              <div style="margin:0.5em; padding-left:10em;">
                ▶&nbsp;<?=$item_content?>
              </div>
              <div style="margin:0.5em; padding-left:10em;">
                <?php
                	for ($i=0; $i<3; $i++)
                	{
                		if ($image_copied[$i])
                		{
                			$img_name = $image_copied[$i];
                			$img_name = "./data/".$img_name;
                			$img_width = $image_width[$i];

                			echo "<img src='$img_name' width='250' height='230' >"."<br><br>";
                		}
                	}
                ?>
              </div>


         <form name="ripple_form" style="margin-top:1em; margin-left:15em;" method="post" action="insert_ripple.php" enctype="multipart/form-data">
           <input type="hidden" name="name1" value="<?=$item_name?>">
           <input type="hidden" name="num" value="<?=$item_num?>">
            <textarea rows="5" cols="75" name="ripple_content"><?php echo isset($ripple_content)?$ripple_content:""?></textarea>
          <button type="button" name="click" onclick=check_input(this.form) style="margin-left:5em;">댓글입력</button>
   			</form>

<?php
              $sql="select * from boardripple where parent=$item_num";
              $ripple_result=mysqli_query($con,$sql);
              while ($row_ripple=mysqli_fetch_array($ripple_result)) {
                $ripple_num=$row_ripple['num'];
                $ripple_id=$userid;
                $ripple_product=$item_name;
                $ripple_content=str_replace("\n", "<br>", $row_ripple['content']);
                $ripple_content=str_replace(" ","&nbsp;",$ripple_content);
                $ripple_date=$row_ripple['regist_day'];

               ?>
               <div id="ripple_writer_title">


               </div>
               <div id="writer_title1" style="float:left">[<?=$ripple_id?>]</div>
               <div id="writer_title2" style="float:right"><?=$ripple_date?></div>
               <div id="writer_title3">
                 <?php
                 if($userid=="admin")
                 echo "<a href='delete_ripple.php?name=<?=$ripple_product?>&num=<?=$ripple_num?>'>[삭제]</a>";
                 ?>
               </div>
               <div style="margin:0.5em; padding-left:10em;">
                   ▶&nbsp;<?=$ripple_content?></div>
         			<div class="hor_line_ripple"></div>
<?php
         		}
         ?>
   		</div> <!-- end of ripple -->


      <script type="text/javascript"> 
      function myFunction(id){ 
        var box=document.getElementById(id);
        if(box.className.indexOf("w3-show")==-1){
          box.className+="w3-show";
        }else{
          box.className=box.className.replace("w3-show","");
        }
      } 

      function check_input(f){
        alert(f);
        f.submit();
      }

      </script> 

          </div>
          <?php
            $number--;
             }
          ?>
        </div>



     			<div id="page_button">
     				<div id="page_num"> ◀ 이전 &nbsp;&nbsp;&nbsp;&nbsp;
     <?php
        // 게시판 목록 하단에 페이지 링크 번호 출력
        for ($i=1; $i<=$total_page; $i++)
        {
     		if ($page == $i)     // 현재 페이지 번호 링크 안함
     		{
     			echo "<b> $i </b>";
     		}
     		else
     		{
     			echo "<a href='list.php?table=board&page=$i'> $i </a>";
     		}
        }
     ?>
     			&nbsp;&nbsp;&nbsp;&nbsp;다음 ▶
     				</div>

    </div>
    <div style="margin-left:60em;width:18%;text-align:center;margin-top:2em;">
<?php if (!isset($userid)) {
  echo "alert('로그인 후 사용가능합니다.')";
} else{?>
      <a href="write_form.php?name=<?=$detail_name?>"><img src="./photo/write.png"></a>
    <?php } ?>
    </div>
    </div>
  </div>



  <div id="Q" >
    <b id="Qb">Q&A</b><br/>
    <p  style="margin-left:12em;font-size:90%">상품에 대해 궁금한 점을 해결해 드립니다.</p>
  <p align="middle">
    <iframe src="../comet_chat/index.php?name=<?=$userid?>" width="700" height="300" scrolling="yes"></iframe>
  </div>
  </p>
  </div>
</div>
   </body>
 </html>
