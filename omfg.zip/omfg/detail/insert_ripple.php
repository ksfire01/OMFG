<?php
   session_start();
   include "./lib/dbconn.php";
   if(isset($_SESSION['userid']))
 	$userid=$_SESSION['userid'];     // dconn.php 파일을 불러옴
?>
<meta charset="utf-8">
<?php
$name=$_POST['name1'];
$num=$_POST['num'];
$content=$_POST['ripple_content'];


   if(!isset($userid)) {
     echo("
	   <script>
	     window.alert('로그인 후 이용하세요.')
	     history.go(-1)
	   </script>
	 ");
	 exit;
   }

   $regist_day = date("Y-m-d (H:i)");  // 현재의 '년-월-일-시-분'을 저장

   // 레코드 삽입 명령
   $sql = "insert into boardripple (parent, id, productname,  content, regist_day) ";
   $sql .= "values($num, '$userid', '$name',  '$content', '$regist_day')";

   mysqli_query($con,$sql);  // $sql 에 저장된 명령 실행
   mysqli_close($con);                // DB 연결 끊기

   echo "
  <script>
   location.href = 'detailpage.php?name=<?=$name?>';
  </script>
 ";

?>
